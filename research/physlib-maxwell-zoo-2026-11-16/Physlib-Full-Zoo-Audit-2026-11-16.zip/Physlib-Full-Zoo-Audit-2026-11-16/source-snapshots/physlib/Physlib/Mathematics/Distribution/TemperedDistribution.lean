/-
Copyright (c) 2025 Kenny Lau. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Kenny Lau, Joseph Tooby-Smith
-/
module

public import Mathlib.Analysis.Distribution.TemperedDistribution
public import Mathlib.MeasureTheory.Measure.CharacteristicFunction.Basic
/-!

# Distributions

## i. Overview

Distributions are often used implicitly in physics, for example the correct way to handle
a dirac delta function is to treat it as a distribution. In this file we will
define distributions and some properties on them.

The distributions from a space `E` to space `F` can be thought of as a generalization of
functions from `E` to `F`. We give a more precise definition of distributions below.

In this file we define distributions generally. Properties of distributions directly related to
`Space` are defined in the `Physlib.SpaceAndTime.Space` directory, for example in
`Physlib.SpaceAndTime.Space.DistOfFunction`.

## ii. Key results

- `E →d[𝕜] F` is the type of distributions from `E` to `F`.
- `Distribution.derivative` and `Distribution.fourierTransform` allow us to make sense of these
  operations that might not make sense a priori on general functions.
- `Distribution.toTemperedDistribution` converts a Physlib distribution to a Mathlib
  tempered distribution.
- `Distribution.ofFiniteMeasure` is the scalar distribution associated to a finite measure.
- `Distribution.ofFiniteMeasure_eq_iff` says that finite measures are determined by their
  associated complex scalar distributions.
- `Distribution.integralOfBound` integrates a family with an integrable Schwartz seminorm bound.
- `Distribution.fderivD_integralOfBound_apply` differentiates this integral after evaluation.

## iii. Table of contents

- A. The definition of a distribution
- B. Construction of distributions from linear maps
- C. Derivatives of distributions
  - C.1. Differentiating integrals of distributions
- D. Fourier transform of distributions
  - D.1. Bridge to Mathlib tempered distributions
- E. Specific distributions
  - E.1. The constant distribution
  - E.2. Distributions associated to finite measures
  - E.3. The dirac delta distribution
  - E.4. The heaviside step function

## iv. References

* None.

-/

@[expose] public section

open SchwartzMap NNReal
open scoped ENNReal SchwartzMap FourierTransform
noncomputable section

/-!

## A. The definition of a distribution

In physics, we often encounter mathematical objects like the Dirac delta function `δ(x)`
that are not functions in the traditional sense.
Distributions provide a rigorous framework for handling such objects.

The core idea is to define a "generalized function" not by its value at each point,
but by how it acts on a set of well-behaved "test functions".

These test functions, typically denoted `η`. The choice of test functions depends on the application
here we choose test functions which are smooth and decay
rapidly at infinity (called Schwartz maps). Thus really the distributions we are defining here
are called tempered distributions.

A distribution `u` is a linear map that takes a test function `η` and produces a value,
which can be a scalar or a vector. This action is written as `⟪u,η⟫`.

Two key examples illustrate this concept:

1. **Ordinary Functions:** Any well-behaved function `f(x)` can be viewed as a distribution.
  Its action on a test function `η` is defined by integration:
  `u_f(η) = ∫ f(x) η(x) dx`
  This integral "tests" the function `f` using `η`.

2. **Dirac Delta:** The Dirac delta `δ_a` (centered at `a`) is a distribution whose action is to
  simply evaluate the test function at `a`:
  `δ_a(η) = η(a)`

Formally, a distribution is a *continuous linear map* from the space of Schwartz functions
`𝓢(E, 𝕜)` to a
vector space `F` over `𝕜`. This definition allows us to rigorously define concepts
like derivatives and Fourier transforms for these generalized functions, as we will see below.

We use the notation `E →d[𝕜] F` to denote the space of distributions from `E` to `F`
where `E` is a normed vector space over `ℝ` and `F` is a normed vector space over `𝕜`.

-/

/- Need the `Physlib` namespace to prevent conflict with Mathlib's distributions. -/
namespace Physlib

/-- An `F`-valued distribution on `E` (where `E` is a normed vector space over `ℝ` and `F` is a
normed vector space over `𝕜`) is a continuous linear map `𝓢(E, 𝕜) →L[𝕜] F` where `𝒮(E, 𝕜)` is
the Schwartz space of smooth functions `E → 𝕜` with rapidly decreasing iterated derivatives. This
is notated as `E →d[𝕜] F`.

This should be seen as a generalisation of functions `E → F`. -/
abbrev Distribution (𝕜 E F : Type) [RCLike 𝕜] [NormedAddCommGroup E] [NormedAddCommGroup F]
    [NormedSpace ℝ E] [NormedSpace 𝕜 F] : Type :=
  𝓢(E, 𝕜) →L[𝕜] F

@[inherit_doc] notation:25 E:arg "→d[" 𝕜:25 "] " F:0 => Distribution 𝕜 E F

variable (𝕜 : Type) {E F : Type} [RCLike 𝕜] [NormedAddCommGroup E] [NormedAddCommGroup F]

namespace Distribution

section NormedSpace

variable [NormedSpace ℝ E] [NormedSpace 𝕜 F]

/-!

## B. Construction of distributions from linear maps

Distributions are defined as **continuous** linear maps from `𝓢(E, 𝕜)` to `F`.
It is possible to define a constructor of distributions from just linear maps
`𝓢(E, 𝕜) →ₗ[𝕜] F` (without the continuity requirement) by imposing a condition
on the size of `u` applied to `η`.

-/

/-- The construction of a distribution from the following data:
1. We take a finite set `s` of pairs `(k, n) ∈ ℕ × ℕ` that will be explained later.
2. We take a linear map `u` that evaluates the given Schwartz function `η`. At this stage we don't
  need `u` to be continuous.
3. Recall that a Schwartz function `η` satisfies a bound
  `‖x‖ᵏ * ‖(dⁿ/dxⁿ) η‖ < Mₙₖ` where `Mₙₖ : ℝ` only depends on `(k, n) : ℕ × ℕ`.
4. This step is where `s` is used: for each test function `η`, the norm `‖u η‖` is required to be
  bounded by `C * (‖x‖ᵏ * ‖(dⁿ/dxⁿ) η‖)` for some `x : ℝ` and for some `(k, n) ∈ s`, where
  `C ≥ 0` is a global scalar.
-/
def ofLinear (s : Finset (ℕ × ℕ)) (u : 𝓢(E, 𝕜) →ₗ[𝕜] F)
    (hu : ∃ C : ℝ, 0 ≤ C ∧ ∀ η : 𝓢(E, 𝕜), ∃ (k : ℕ) (n : ℕ) (x : E), (k, n) ∈ s ∧
      ‖u η‖ ≤ C * (‖x‖ ^ k * ‖iteratedFDeriv ℝ n η x‖)) : E →d[𝕜] F :=
  mkCLMtoNormedSpace u (by simp) (by simp) <| by
    obtain ⟨C, hC, hu⟩ := hu
    refine ⟨s, C, hC, fun η ↦ ?_⟩
    obtain ⟨k, n, x, hkn, hη⟩ := hu η
    refine hη.trans <| mul_le_mul_of_nonneg_left ((le_seminorm 𝕜 k n η x).trans ?_) hC
    rw [Seminorm.finset_sup_apply]
    refine (NNReal.coe_le_coe (r₁ := ⟨SchwartzMap.seminorm 𝕜 k n η, apply_nonneg _ _⟩)).2 ?_
    exact s.le_sup hkn
      (f := fun kn : ℕ × ℕ ↦ (⟨SchwartzMap.seminorm 𝕜 kn.1 kn.2 η, apply_nonneg _ _⟩ : ℝ≥0))

@[simp] lemma ofLinear_apply (s : Finset (ℕ × ℕ)) (u : 𝓢(E, 𝕜) →ₗ[𝕜] F)
    (hu : ∃ C : ℝ, 0 ≤ C ∧ ∀ η : 𝓢(E, 𝕜), ∃ (k : ℕ) (n : ℕ) (x : E), (k, n) ∈ s ∧
      ‖u η‖ ≤ C * (‖x‖ ^ k * ‖iteratedFDeriv ℝ n η x‖))
    (η : 𝓢(E, 𝕜)) :
    ofLinear 𝕜 s u hu η = u η :=
  rfl

end NormedSpace

/-!

## C. Derivatives of distributions

Given a distribution `u : E →d[𝕜] F`, we can define the derivative of that distribution.
In general when defining an operation on a distribution, we do it by applying a similar
operation instead to the Schwartz maps it acts on.

Thus the derivative of `u` is the distribution which takes `η` to `⟪u, - η'⟫`
where `η'` is the derivative of `η`.

The derivative commutes with finite superpositions of sources: for a family `u` and a finite
index set `s`, the identity `fderivD 𝕜 (∑ i ∈ s, u i) = ∑ i ∈ s, fderivD 𝕜 (u i)` follows from
`map_sum (fderivD 𝕜) u s`, since `fderivD 𝕜` is a linear map. Integrals of families of
distributions are treated in the next subsection.

-/

section fderiv

variable [NormedSpace ℝ E] [NormedSpace ℝ F] [NormedSpace 𝕜 F] [SMulCommClass ℝ 𝕜 F]

/-- The Fréchet derivative of a distribution.

Informally, for a distribution `u : E →d[𝕜] F`,
the Fréchet derivative `fderiv u x v` corresponds to the derivative of `u` at the
point `x` in the direction `v`. For example, if `F = ℝ³`
then `fderiv u x v` is a vector in `ℝ³` corresponding to
`(v₁ ∂u₁/∂x₁ + v₂ ∂u₁/∂x₂ + v₃ ∂u₁/∂x₃, v₁ ∂u₂/∂x₁ + v₂ ∂u₂/∂x₂ + v₃ ∂u₂/∂x₃,...)`.

Formally, for a distribution `u : E →d[𝕜] F`, this is actually defined
the distribution which takes test function `η : E → 𝕜` to
`- u (SchwartzMap.evalCLM v (SchwartzMap.fderivCLM 𝕜 η))`.

Note that, unlike for functions, the Fréchet derivative of a distribution always exists.
-/
def fderivD [FiniteDimensional ℝ E] : (E →d[𝕜] F) →ₗ[𝕜] (E →d[𝕜] (E →L[ℝ] F)) where
  toFun u := {
    toFun η := LinearMap.toContinuousLinearMap {
      toFun v := ContinuousLinearEquiv.neg 𝕜 <| u <|
        SchwartzMap.evalCLM (𝕜 := 𝕜) E 𝕜 v <|
        SchwartzMap.fderivCLM 𝕜 (E := E) (F := 𝕜) η
      map_add' v1 v2 := by
        simp only [ContinuousLinearEquiv.neg_apply]
        trans -u ((SchwartzMap.evalCLM (𝕜 := 𝕜) E 𝕜 v1) ((fderivCLM 𝕜) E 𝕜 η) +
          (SchwartzMap.evalCLM (𝕜 := 𝕜) E 𝕜 v2) ((fderivCLM 𝕜) E 𝕜 η))
        swap
        · simp only [map_add, neg_add_rev]
          abel
        congr
        ext x
        simp only [SchwartzMap.evalCLM, mkCLM, mkLM, map_add, ContinuousLinearMap.coe_mk',
          LinearMap.coe_mk, AddHom.coe_mk, fderivCLM_apply, add_apply]
        rfl
      map_smul' a v1 := by
        simp only [ContinuousLinearEquiv.neg_apply, RingHom.id_apply, smul_neg, neg_inj]
        trans u (a • (SchwartzMap.evalCLM (𝕜 := 𝕜) E 𝕜 v1) ((fderivCLM 𝕜) E 𝕜 η))
        swap
        · simp
        congr
        ext x
        simp only [SchwartzMap.evalCLM, mkCLM, mkLM, map_smul, ContinuousLinearMap.coe_mk',
          LinearMap.coe_mk, AddHom.coe_mk, fderivCLM_apply, smul_apply]
        rfl}
    map_add' η1 η2 := by
      ext x
      simp only [map_add, ContinuousLinearEquiv.neg_apply,
        LinearMap.coe_toContinuousLinearMap', LinearMap.coe_mk, AddHom.coe_mk,
        add_apply]
    map_smul' a η := by
      ext x
      simp
    cont := by
      refine continuous_clm_apply.mpr ?_
      intro y
      simp only [ContinuousLinearEquiv.neg_apply, LinearMap.coe_toContinuousLinearMap',
        LinearMap.coe_mk, AddHom.coe_mk]
      fun_prop
  }
  map_add' u₁ u₂ := by
    ext η
    simp only [add_apply, ContinuousLinearEquiv.neg_apply, neg_add_rev,
      ContinuousLinearMap.coe_mk', LinearMap.coe_mk, AddHom.coe_mk,
      LinearMap.coe_toContinuousLinearMap']
    abel
  map_smul' c u := by
    ext
    simp

lemma fderivD_apply [FiniteDimensional ℝ E] (u : E →d[𝕜] F) (η : 𝓢(E, 𝕜)) (v : E) :
    fderivD 𝕜 u η v = - u (SchwartzMap.evalCLM (𝕜 := 𝕜) E 𝕜 v (SchwartzMap.fderivCLM 𝕜 E 𝕜 η)) := by
  rfl

end fderiv

/-!

### C.1. Differentiating integrals of distributions

Superpositions of generalized sources can be described by integrating families of distributions.
We construct this weak integral when evaluations are measurable and bounded by an integrable
coefficient times a fixed finite maximum of Schwartz seminorms. This bound ensures that the
integral is continuous on the test functions. Distributional differentiation then commutes with
the integral after evaluation at a test function and a direction.

-/

section integral

open MeasureTheory

variable {𝕜} {A : Type} [MeasurableSpace A] {μ : Measure A}
  [NormedSpace ℝ E] [NormedSpace 𝕜 F]
  (u : A → E →d[𝕜] F) (s : Finset (ℕ × ℕ)) (b : A → ℝ) (hb : Integrable b μ)
  (hmeas : ∀ η : 𝓢(E, 𝕜), AEStronglyMeasurable (fun a => u a η) μ)
  (hbound : ∀ η : 𝓢(E, 𝕜), ∀ᵐ a ∂μ,
    ‖u a η‖ ≤ b a * s.sup (schwartzSeminormFamily 𝕜 E 𝕜) η)

include hb hmeas hbound

/-- Evaluations of a distribution family with an integrable seminorm bound are integrable. -/
lemma integrable_eval_of_bound (η : 𝓢(E, 𝕜)) : Integrable (fun a => u a η) μ :=
  (hb.mul_const _).mono' (hmeas η) (hbound η)

variable [NormedSpace ℝ F] (hb_nonneg : ∀ᵐ a ∂μ, 0 ≤ b a)

/-- The weak integral of a family of distributions with an integrable Schwartz seminorm bound.
It acts on a test function by integrating the evaluations of the family. -/
def integralOfBound : E →d[𝕜] F :=
  mkCLMtoNormedSpace (fun η => ∫ a, u a η ∂μ)
    (by
      intro η ξ
      simp only [map_add]
      exact integral_add (integrable_eval_of_bound u s b hb hmeas hbound η)
        (integrable_eval_of_bound u s b hb hmeas hbound ξ))
    (by
      intro c η
      simp only [map_smul]
      exact integral_smul c (fun a => u a η))
    (by
      refine ⟨s, ∫ a, b a ∂μ, integral_nonneg_of_ae hb_nonneg, fun η => ?_⟩
      calc
        ‖∫ a, u a η ∂μ‖ ≤ ∫ a, b a * s.sup (schwartzSeminormFamily 𝕜 E 𝕜) η ∂μ :=
          norm_integral_le_of_norm_le (hb.mul_const _) (hbound η)
        _ = (∫ a, b a ∂μ) * s.sup (schwartzSeminormFamily 𝕜 E 𝕜) η :=
          integral_mul_const _ _)

/-- Evaluation of the weak integral is the integral of the evaluations. -/
@[simp]
lemma integralOfBound_apply (η : 𝓢(E, 𝕜)) :
    integralOfBound u s b hb hmeas hbound hb_nonneg η = ∫ a, u a η ∂μ :=
  rfl

variable [SMulCommClass ℝ 𝕜 F] [FiniteDimensional ℝ E]

/-- Differentiated evaluations of a family with an integrable seminorm bound are integrable. -/
lemma integrable_fderivD_eval_of_bound (η : 𝓢(E, 𝕜)) (v : E) :
    Integrable (fun a => fderivD 𝕜 (u a) η v) μ := by
  simp only [fderivD_apply]
  exact (integrable_eval_of_bound u s b hb hmeas hbound _).neg

/-- Distributional differentiation commutes with the weak integral after evaluation at a test
function and a direction. -/
lemma fderivD_integralOfBound_apply (η : 𝓢(E, 𝕜)) (v : E) :
    fderivD 𝕜 (integralOfBound u s b hb hmeas hbound hb_nonneg) η v =
      ∫ a, fderivD 𝕜 (u a) η v ∂μ := by
  simp only [fderivD_apply, integralOfBound_apply, integral_neg]

end integral

/-!

## D. Fourier transform of distributions

As with derivatives of distributions we can define the fourier transform of a distribution
by taking the fourier transform of the underlying Schwartz maps. Thus the fourier transform
of the distribution `u` is the distribution which takes `η` to `⟪u, F[η]⟫` where `F[η]` is the
fourier transform of `η`.

-/

section Complex

variable [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
  [NormedSpace ℂ F]

variable (E F) in
/-- Definition of Fourier transform of distribution: Let `u` be a distribution. Then its Fourier
transform is `F{u}` where given a test function `η`, `F{u}(η) := u(F{η})`. -/
def fourierTransform : (E →d[ℂ] F) →ₗ[ℂ] (E →d[ℂ] F) where
  toFun u := u.comp <| fourierTransformCLM ℂ (E := ℂ) (V := E)
  map_add' u₁ u₂ := by simp
  map_smul' c u := by simp

@[simp] lemma fourierTransform_apply (u : E →d[ℂ] F) (η : 𝓢(E, ℂ)) :
    u.fourierTransform E F η = u (fourierTransformCLM ℂ η) :=
  rfl

end Complex

/-!

### D.1. Bridge to Mathlib tempered distributions

Mathlib's tempered distributions use the pointwise convergence topology on the same underlying
continuous linear maps. The following construction converts Physlib distributions to that API.

-/
section TemperedDistribution

variable [NormedSpace ℝ E] [NormedSpace ℂ F]

/-- The Mathlib tempered distribution associated to a Physlib distribution. -/
def toTemperedDistribution (u : E →d[ℂ] F) : 𝓢'(E, F) :=
  ContinuousLinearMap.toPointwiseConvergenceCLM _ _ _ _ u

@[simp]
lemma toTemperedDistribution_apply (u : E →d[ℂ] F) (η : 𝓢(E, ℂ)) :
    u.toTemperedDistribution η = u η :=
  rfl

end TemperedDistribution

section TemperedDistributionFourier

variable [InnerProductSpace ℝ E] [FiniteDimensional ℝ E] [MeasurableSpace E] [BorelSpace E]
  [NormedSpace ℂ F]

/-- Conversion to Mathlib tempered distributions commutes with the Fourier transform. -/
@[simp]
lemma toTemperedDistribution_fourierTransform (u : E →d[ℂ] F) :
    (u.fourierTransform E F).toTemperedDistribution = 𝓕 u.toTemperedDistribution :=
  rfl

end TemperedDistributionFourier

/-!

## E. Specific distributions

We now define specific distributions, which are used throughout physics. In particular, we define:
- The constant distribution.
- Distributions associated to finite measures.
- The dirac delta distribution.
- The heaviside step function.

-/

section constant
/-!

### E.1. The constant distribution

The constant distribution is the distribution which corresponds to a constant function,
it takes `η` to the integral of `η` over the volume measure.

-/
open MeasureTheory
section
variable (E : Type) [NormedAddCommGroup E]
  [NormedSpace ℝ E] [NormedSpace ℝ F]
  [NormedSpace 𝕜 F] [SMulCommClass ℝ 𝕜 F]
  [MeasureSpace E] [BorelSpace E] [SecondCountableTopology E]

/-- The constant distribution `E →d[𝕜] F`, for a given `c : F` this corresponds
  to the integral `∫ x, η x • c ∂MeasureTheory.volume`. -/
def const [hμ : Measure.HasTemperateGrowth (volume (α := E))] (c : F) : E →d[𝕜] F := by
  refine mkCLMtoNormedSpace
    (fun η => ∫ x, η x • c ∂MeasureTheory.volume) ?_
    ?_ ?_
  · intro η1 η2
    simp [add_smul]
    by_cases hc : c = 0
    · subst hc
      simp
    rw [MeasureTheory.integral_add]
    · refine (integrable_smul_const hc).mpr ?_
      exact integrable η1
    · refine (integrable_smul_const hc).mpr ?_
      exact integrable η2
  · intro a η
    simp only [smul_apply, RingHom.id_apply, smul_assoc]
    rw [MeasureTheory.integral_smul]
  rcases hμ.exists_integrable with ⟨n, h⟩
  let m := (n, 0)
  use Finset.Iic m, ‖c‖ * (2 ^ n * ∫ x, (1 + ‖x‖) ^ (- (n : ℝ)) ∂(volume (α := E)))
  refine ⟨by positivity, fun η ↦ (norm_integral_le_integral_norm _).trans ?_⟩
  have h' : ∀ x, ‖η x‖ ≤ (1 + ‖x‖) ^ (-(n : ℝ)) *
    (2 ^ n * ((Finset.Iic m).sup (fun m' => SchwartzMap.seminorm 𝕜 m'.1 m'.2) η)) := by
    intro x
    rw [Real.rpow_neg (by positivity), ← div_eq_inv_mul,
      le_div_iff₀' (by positivity), Real.rpow_natCast]
    simpa using one_add_le_sup_seminorm_apply (m := m) (k := n) (n := 0) le_rfl le_rfl η x
  conv_lhs =>
    enter [2, x]
    rw [norm_smul, mul_comm]
  conv_lhs =>
    rw [MeasureTheory.integral_const_mul]
  rw [mul_assoc]
  by_cases hc : c = 0
  · subst hc
    simp
  refine (mul_le_mul_iff_of_pos_left ?_).mpr ?_
  · positivity
  apply (integral_mono (by simpa using η.integrable_pow_mul ((volume)) 0) _ h').trans
  · unfold schwartzSeminormFamily
    rw [integral_mul_const, ← mul_assoc, mul_comm (2 ^ n)]
  apply h.mul_const

lemma const_apply [hμ : Measure.HasTemperateGrowth (volume (α := E))] (c : F)
    (η : 𝓢(E, 𝕜)) :
    const 𝕜 E c η = ∫ x, η x • c ∂MeasureTheory.volume := by rfl
end
section

variable [NormedSpace ℝ E] [NormedSpace ℝ F]
  [MeasureSpace E] [BorelSpace E] [SecondCountableTopology E]

@[simp]
lemma fderivD_const [hμ : Measure.IsAddHaarMeasure (volume (α := E))]
    [FiniteDimensional ℝ E] (c : F) :
    fderivD ℝ (const ℝ E c) = 0 := by
  ext η v
  rw [fderivD_apply, const_apply]
  simp only [zero_apply, neg_eq_zero]
  trans -∫ (x : E), η x • (fderiv ℝ (fun y => c) x) v ∂volume
  swap
  · simp
  rw [integral_smul_fderiv_eq_neg_fderiv_smul_of_integrable]
  · simp only [evalCLM_apply_apply, fderivCLM_apply, neg_neg]
  · exact (integrable ((SchwartzMap.evalCLM ℝ E ℝ v) ((fderivCLM ℝ) E ℝ η))).smul_const c
  · simp
  · exact (integrable η).smul_const c
  · fun_prop
  · simp

end
end constant

/-!

### E.2. Distributions associated to finite measures

Every finite measure has temperate growth, so integrating Schwartz maps against it defines a
scalar distribution.

-/
section finiteMeasure

open MeasureTheory

variable [NormedSpace ℝ E] [MeasurableSpace E] [BorelSpace E] [SecondCountableTopology E]

/-- The scalar distribution associated to a finite measure, acting on a Schwartz map by
integration. -/
def ofFiniteMeasure (μ : Measure E) [IsFiniteMeasure μ] : E →d[𝕜] 𝕜 :=
  integralCLM 𝕜 μ

@[simp]
lemma ofFiniteMeasure_apply (μ : Measure E) [IsFiniteMeasure μ] (η : 𝓢(E, 𝕜)) :
    ofFiniteMeasure 𝕜 μ η = ∫ x, η x ∂μ :=
  rfl

/-- The finite-measure distribution agrees with Mathlib's tempered distribution associated to the
same measure. -/
@[simp]
lemma toTemperedDistribution_ofFiniteMeasure (μ : Measure E) [IsFiniteMeasure μ] :
    (ofFiniteMeasure ℂ μ).toTemperedDistribution = μ.toTemperedDistribution :=
  rfl

omit [NormedAddCommGroup E] [NormedSpace ℝ E] [BorelSpace E]
  [SecondCountableTopology E] in
private lemma lipschitzWith_integral_of_le {μ ρ : Measure E} (hμρ : μ ≤ ρ) :
    LipschitzWith 1 (fun f : Lp ℂ 1 ρ => ∫ x, f x ∂μ) := by
  refine LipschitzWith.of_dist_le_mul fun f g => ?_
  rw [dist_eq_norm, dist_eq_norm, NNReal.coe_one, one_mul]
  have hfμ : Integrable (fun x => f x) μ :=
    memLp_one_iff_integrable.mp ((Lp.memLp f).mono_measure hμρ)
  have hgμ : Integrable (fun x => g x) μ :=
    memLp_one_iff_integrable.mp ((Lp.memLp g).mono_measure hμρ)
  have hfg_ae : (fun x => (f - g : Lp ℂ 1 ρ) x) =ᵐ[ρ] fun x => f x - g x :=
    Lp.coeFn_sub f g
  have hfg_top : eLpNorm (fun x => f x - g x) 1 ρ ≠ ∞ := by
    rw [← eLpNorm_congr_ae hfg_ae]
    exact (Lp.memLp (f - g)).eLpNorm_ne_top
  calc
    ‖∫ x, f x ∂μ - ∫ x, g x ∂μ‖
        = ‖∫ x, (f x - g x) ∂μ‖ := by rw [integral_sub hfμ hgμ]
    _ ≤ (∫⁻ x, ‖f x - g x‖ₑ ∂μ).toReal := by
      simpa only [ofReal_norm, eLpNorm_one_eq_lintegral_enorm] using
        MeasureTheory.norm_integral_le_lintegral_norm (μ := μ) (fun x => f x - g x)
    _ ≤ (eLpNorm (fun x => f x - g x) 1 ρ).toReal := by
      refine ENNReal.toReal_mono hfg_top ?_
      have hfg_meas : AEStronglyMeasurable (fun x => f x - g x) μ :=
        (hfμ.sub hgμ).aestronglyMeasurable
      rw [← eLpNorm_one_eq_lintegral_enorm hfg_meas]
      exact eLpNorm_mono_measure (p := (1 : ℝ≥0∞)) (fun x => f x - g x) hμρ
    _ = ‖f - g‖ := by rw [Lp.norm_def, eLpNorm_congr_ae hfg_ae]

private lemma integral_boundedContinuous_eq_of_forall_schwartz_integral_eq
    [FiniteDimensional ℝ E] {μ ν : Measure E} [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (h : ∀ η : 𝓢(E, ℂ), ∫ x, η x ∂μ = ∫ x, η x ∂ν)
    (f : BoundedContinuousFunction E ℂ) :
    ∫ x, f x ∂μ = ∫ x, f x ∂ν := by
  let ρ : Measure E := μ + ν
  have : IsFiniteMeasure ρ := inferInstance
  have : ρ.HasTemperateGrowth := inferInstance
  let L : 𝓢(E, ℂ) →L[ℝ] Lp ℂ 1 ρ :=
    SchwartzMap.toLpCLM ℝ ℂ 1 ρ
  let toL1 : BoundedContinuousFunction E ℂ →L[ℝ] Lp ℂ 1 ρ :=
    BoundedContinuousFunction.toLp 1 ρ ℝ
  let S : Set (Lp ℂ 1 ρ) := {u | ∫ x, u x ∂μ = ∫ x, u x ∂ν}
  have hS_closed : IsClosed S :=
    isClosed_eq
      (lipschitzWith_integral_of_le (μ := μ) (ρ := ρ)
        (Measure.le_add_right le_rfl)).continuous
      (lipschitzWith_integral_of_le (μ := ν) (ρ := ρ)
        (Measure.le_add_left le_rfl)).continuous
  have h_range_subset : Set.range L ⊆ S := by
    rintro u ⟨η, rfl⟩
    dsimp [S, L]
    have hηρ : (L η : E → ℂ) =ᵐ[ρ] η := by
      simpa [L] using SchwartzMap.coeFn_toLp η (1 : ℝ≥0∞) ρ
    have hημ : (L η : E → ℂ) =ᵐ[μ] η :=
      (Measure.absolutelyContinuous_of_le (Measure.le_add_right le_rfl)) hηρ
    have hην : (L η : E → ℂ) =ᵐ[ν] η :=
      (Measure.absolutelyContinuous_of_le (Measure.le_add_left le_rfl)) hηρ
    calc
      ∫ x, (L η : E → ℂ) x ∂μ = ∫ x, η x ∂μ := integral_congr_ae hημ
      _ = ∫ x, η x ∂ν := h η
      _ = ∫ x, (L η : E → ℂ) x ∂ν := (integral_congr_ae hην).symm
  have hS_univ : Set.univ ⊆ S := by
    rw [← (SchwartzMap.denseRange_toLpCLM (E := E) (F := ℂ) (p := (1 : ℝ≥0∞))
      (μ := ρ) ENNReal.one_ne_top).closure_range]
    exact hS_closed.closure_subset_iff.mpr h_range_subset
  have hfS : toL1 f ∈ S := hS_univ trivial
  dsimp [S, toL1] at hfS
  have hfρ : (toL1 f : E → ℂ) =ᵐ[ρ] f := by
    simpa [toL1] using BoundedContinuousFunction.coeFn_toLp (1 : ℝ≥0∞) ρ ℝ f
  have hfμ : (toL1 f : E → ℂ) =ᵐ[μ] f :=
    (Measure.absolutelyContinuous_of_le (Measure.le_add_right le_rfl)) hfρ
  have hfν : (toL1 f : E → ℂ) =ᵐ[ν] f :=
    (Measure.absolutelyContinuous_of_le (Measure.le_add_left le_rfl)) hfρ
  calc
    ∫ x, f x ∂μ = ∫ x, (toL1 f : E → ℂ) x ∂μ := (integral_congr_ae hfμ).symm
    _ = ∫ x, (toL1 f : E → ℂ) x ∂ν := hfS
    _ = ∫ x, f x ∂ν := integral_congr_ae hfν

end finiteMeasure

section finiteMeasureExt

open MeasureTheory

private lemma measure_eq_of_forall_schwartz_integral_eq
    {E : Type} [NormedAddCommGroup E] [NormedSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [SecondCountableTopology E] [FiniteDimensional ℝ E]
    {μ ν : Measure E} [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (h : ∀ η : 𝓢(E, ℂ), ∫ x, η x ∂μ = ∫ x, η x ∂ν) :
    μ = ν := by
  refine Measure.ext_of_charFunDual (funext fun L => ?_)
  rw [charFunDual_apply, charFunDual_apply]
  exact integral_boundedContinuous_eq_of_forall_schwartz_integral_eq h
    (BoundedContinuousFunction.probCharDual L)

/-- The complex scalar distribution associated to a finite measure determines the measure. -/
lemma ofFiniteMeasure_eq_iff
    {E : Type} [NormedAddCommGroup E] [NormedSpace ℝ E] [MeasurableSpace E]
    [BorelSpace E] [SecondCountableTopology E] [FiniteDimensional ℝ E]
    {μ ν : Measure E} [IsFiniteMeasure μ] [IsFiniteMeasure ν] :
    ofFiniteMeasure ℂ μ = ofFiniteMeasure ℂ ν ↔ μ = ν := by
  refine ⟨fun hdist => measure_eq_of_forall_schwartz_integral_eq fun η => ?_, ?_⟩
  · rw [← ofFiniteMeasure_apply (𝕜 := ℂ) μ η, ← ofFiniteMeasure_apply (𝕜 := ℂ) ν η, hdist]
  · rintro rfl
    rfl

end finiteMeasureExt

/-!

### E.3. The dirac delta distribution

The dirac delta distribution centered at `a : E` is the distribution which takes
`η` to `η a`. We also define `diracDelta'` which takes in an element of `v` of `F` and
outputs `η a • v`.

-/

section DiracDelta

open ContinuousLinearMap

variable [NormedSpace ℝ E] [NormedSpace 𝕜 F]

/-- Dirac delta distribution `diracDelta 𝕜 a : E →d[𝕜] 𝕜` takes in a test function `η : 𝓢(E, 𝕜)`
and outputs `η a`. Intuitively this is an infinite density at a single point `a`. -/
def diracDelta (a : E) : E →d[𝕜] 𝕜 :=
  toPointwiseConvergenceCLM _ _ _ _ <|
    (BoundedContinuousFunction.evalCLM 𝕜 a).comp (toBoundedContinuousFunctionCLM 𝕜 E 𝕜)

@[simp] lemma diracDelta_apply (a : E) (η : 𝓢(E, 𝕜)) :
    diracDelta 𝕜 a η = η a :=
  rfl

/-- Dirac delta in a given direction `v : F`. `diracDelta' 𝕜 a v` takes in a test function
`η : 𝓢(E, 𝕜)` and outputs `η a • v`. Intuitively this is an infinitely intense vector field
at a single point `a` pointing at the direction `v`. -/
def diracDelta' (a : E) (v : F) : E →d[𝕜] F :=
  ContinuousLinearMap.smulRight (diracDelta 𝕜 a) v

@[simp] lemma diracDelta'_apply (a : E) (v : F) (η : 𝓢(E, 𝕜)) :
    diracDelta' 𝕜 a v η = η a • v :=
  rfl

end DiracDelta
/-!

### E.4. The heaviside step function

The heaviside step function on `EuclideanSpace ℝ (Fin d.succ)` is the distribution
from `EuclideanSpace ℝ (Fin d.succ)` to `ℝ` which takes a `η` to the integral of `η` in the
upper-half plane (determined by the last coordinate in `EuclideanSpace ℝ (Fin d.succ)`).

-/
open MeasureTheory

/-- The Heaviside step distribution defined on `(EuclideanSpace ℝ (Fin d.succ)) `
  equal to `1` in the positive `z`-direction and `0` in the negative `z`-direction. -/
def heavisideStep (d : ℕ) : (EuclideanSpace ℝ (Fin d.succ)) →d[ℝ] ℝ := by
  refine mkCLMtoNormedSpace
    (fun η =>
    ∫ x in {x : EuclideanSpace ℝ (Fin d.succ) | 0 < x (Fin.last d)}, η x ∂MeasureTheory.volume) ?_
    ?_ ?_
  · intro η1 η2
    simp only [Nat.succ_eq_add_one, add_apply]
    rw [MeasureTheory.integral_add]
    · apply MeasureTheory.Integrable.restrict
      exact integrable η1
    · apply MeasureTheory.Integrable.restrict
      exact integrable η2
  · intro a η
    simp only [smul_apply, RingHom.id_apply]
    rw [MeasureTheory.integral_smul]
  have hμ : (volume (α := EuclideanSpace ℝ (Fin d.succ))).HasTemperateGrowth := by
    infer_instance
  rcases hμ.exists_integrable with ⟨n, h⟩
  let m := (n, 0)
  use Finset.Iic m, 2 ^ n *
    ∫ x, (1 + ‖x‖) ^ (- (n : ℝ)) ∂(volume (α := EuclideanSpace ℝ (Fin d.succ)))
  refine ⟨by positivity, fun η ↦ (norm_integral_le_integral_norm _).trans ?_⟩
  trans ∫ x, ‖η x‖ ∂(volume (α := EuclideanSpace ℝ (Fin d.succ)))
  · refine setIntegral_le_integral ?_ ?_
    · have hi := integrable η (μ := volume)
      fun_prop
    · filter_upwards with x
      simp
  · have h' : ∀ x, ‖η x‖ ≤ (1 + ‖x‖) ^ (-(n : ℝ)) *
      (2 ^ n * ((Finset.Iic m).sup (fun m' => SchwartzMap.seminorm ℝ m'.1 m'.2) η)) := by
      intro x
      rw [Real.rpow_neg (by positivity), ← div_eq_inv_mul,
        le_div_iff₀' (by positivity), Real.rpow_natCast]
      simpa using one_add_le_sup_seminorm_apply (m := m) (k := n) (n := 0) le_rfl le_rfl η x
    apply (integral_mono (by simpa using η.integrable_pow_mul ((volume)) 0) _ h').trans
    · unfold schwartzSeminormFamily
      rw [integral_mul_const, ← mul_assoc, mul_comm (2 ^ n)]
    apply h.mul_const

lemma heavisideStep_apply (d : ℕ) (η : 𝓢(EuclideanSpace ℝ (Fin d.succ), ℝ)) :
    heavisideStep d η = ∫ x in {x : EuclideanSpace ℝ (Fin d.succ) | 0 < x (Fin.last d)},
      η x ∂MeasureTheory.volume := by
  rfl

end Distribution
end Physlib
