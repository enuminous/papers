import json
import unittest
from pathlib import Path

from pegasus.audit import (FAIL, PASS, UNRESOLVED, affine_power_identity, audit, cube_rotations,
                           fano_automorphisms, integer_volume, order_divides,
                           permutation_group, polynomial_identity, verify_freeze)

ROOT = Path(__file__).resolve().parents[1]


def fixture(name):
    return json.loads((ROOT / "examples" / name).read_text())


def simple_claim(name="a", depends=None, kind="polynomial_identity"):
    return {"id": name, "statement": "Constant polynomial equality", "check": kind,
            "params": {"left": [1], "right": [1]}, "depends_on": depends or []}


def document(claims):
    return {"schema_version": "pegasus-claims/1", "required_claims": [claims[0]["id"]], "claims": claims}


class ExactChecks(unittest.TestCase):
    def test_cubic_identity_expands_expression(self):
        p = dict(polynomial=[0, 6, 12, 8], slope=2, intercept=1, power=3, offset=-1)
        self.assertEqual(affine_power_identity(p)["verdict"], PASS)
        p["polynomial"] = [0, 6, 12, 9]
        self.assertEqual(affine_power_identity(p)["verdict"], FAIL)

    def test_polynomial_coefficients_not_sample_matching(self):
        # x(x-1) vanishes at 0,1, but is not the zero polynomial.
        self.assertEqual(polynomial_identity({"left": [0, -1, 1], "right": [0]})["verdict"], FAIL)

    def test_rational_equivalence(self):
        self.assertEqual(polynomial_identity({"left": ["2/6", 0], "right": ["1/3"]})["verdict"], PASS)

    def test_float_input_rejected(self):
        with self.assertRaises(ValueError):
            polynomial_identity({"left": [0.1], "right": ["1/10"]})

    def test_fractional_cube_count(self):
        r = integer_volume({"polynomial": [0, 6, 12, 8], "scale": "40/39", "start": 1, "stop": 10})
        self.assertEqual(r["verdict"], FAIL)
        self.assertEqual(r["evidence"]["volume"], "80/3")

    def test_integral_window_does_not_claim_universal(self):
        r = integer_volume({"polynomial": [0, 1], "scale": "1/2", "start": 2, "stop": 2})
        self.assertEqual(r["verdict"], PASS)
        self.assertFalse(r["evidence"]["universal_claim"])

    def test_cube_enumeration(self):
        self.assertEqual(cube_rotations({"expected_count": 24})["verdict"], PASS)
        self.assertEqual(cube_rotations({"expected_count": 1})["verdict"], FAIL)

    def test_fano_is_not_m11(self):
        self.assertEqual(fano_automorphisms({"expected_count": 168})["verdict"], PASS)
        self.assertEqual(fano_automorphisms({"expected_count": 7920})["verdict"], FAIL)

    def test_divisibility_not_embedding(self):
        r = order_divides({"child_order": 4, "parent_order": 12})
        self.assertEqual(r["verdict"], PASS)
        self.assertFalse(r["evidence"]["embedding_proven"])
        self.assertEqual(order_divides({"child_order": 7, "parent_order": 12})["verdict"], FAIL)

    def test_group_positive_and_wrong_order(self):
        p = fixture("toy-hybrid.json")["claims"][0]["params"]
        self.assertEqual(permutation_group(p)["evidence"]["order"], 8)
        self.assertEqual(permutation_group(dict(p, expected_order=7))["verdict"], FAIL)

    def test_group_budget_is_unresolved(self):
        p = fixture("toy-hybrid.json")["claims"][0]["params"]
        self.assertEqual(permutation_group(dict(p, max_elements=3))["verdict"], UNRESOLVED)

    def test_non_bijection_is_invalid(self):
        with self.assertRaises(ValueError):
            permutation_group({"degree": 2, "generators": [[0, 0]], "expected_order": 1})


class EvidenceControls(unittest.TestCase):
    def test_unknown_check_cannot_pass(self):
        self.assertEqual(audit(document([simple_claim(kind="magic")]))["verdict"], UNRESOLVED)

    def test_direct_cycle(self):
        self.assertEqual(audit(document([simple_claim(depends=["a"])]))["verdict"], FAIL)

    def test_indirect_cycle(self):
        claims = [simple_claim("a", ["b"]), simple_claim("b", ["a"])]
        self.assertTrue(all(r["verdict"] == FAIL for r in audit(document(claims))["results"]))

    def test_unresolved_premise_blocks_pass(self):
        claims = [simple_claim("a", ["b"]), simple_claim("b", kind="unimplemented")]
        self.assertEqual(audit(document(claims))["verdict"], UNRESOLVED)

    def test_failed_premise_blocks_pass(self):
        a, b = simple_claim("a", ["b"]), simple_claim("b")
        b["params"]["right"] = [2]
        self.assertEqual(audit(document([a, b]))["verdict"], FAIL)

    def test_required_root_excludes_diagnostic(self):
        a, b = simple_claim("a"), simple_claim("diagnostic")
        b["params"]["right"] = [2]
        r = audit(document([a, b]))
        self.assertEqual(r["verdict"], PASS)
        self.assertEqual(r["counts"][FAIL], 1)

    def test_missing_dependency_rejected(self):
        with self.assertRaises(ValueError):
            audit(document([simple_claim(depends=["absent"])]))

    def test_duplicate_ids_rejected(self):
        with self.assertRaises(ValueError):
            audit(document([simple_claim(), simple_claim()]))

    def test_empty_required_rejected(self):
        d = document([simple_claim()])
        d["required_claims"] = []
        with self.assertRaises(ValueError):
            audit(d)

    def test_prose_cannot_certify_bridge(self):
        c = simple_claim(kind="obligation")
        c["params"] = {"needed": ["checked map"], "notes": "PROVED, PASS, independently replicated"}
        self.assertEqual(audit(document([c]))["verdict"], UNRESOLVED)

    def test_injected_verdict_ignored(self):
        c = simple_claim(kind="unknown")
        c["verdict"] = "PASS"
        self.assertEqual(audit(document([c]))["verdict"], UNRESOLVED)

    def test_original_stays_unresolved(self):
        r = audit(fixture("source-claims.json"))
        self.assertEqual(r["verdict"], UNRESOLVED)
        self.assertGreaterEqual(r["counts"][FAIL], 2)

    def test_toy_is_separate(self):
        self.assertEqual(audit(fixture("toy-hybrid.json"))["verdict"], PASS)

    def test_freeze_integrity(self):
        self.assertEqual(verify_freeze()["verdict"], PASS)


if __name__ == "__main__":
    unittest.main()
