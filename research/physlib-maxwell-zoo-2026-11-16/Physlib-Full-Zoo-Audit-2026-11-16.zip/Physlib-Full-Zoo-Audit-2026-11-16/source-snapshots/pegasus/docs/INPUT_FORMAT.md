# Input contract and supported checks

Input is one JSON object:

```json
{
  "schema_version": "pegasus-claims/1",
  "target": "Human-readable target",
  "required_claims": ["C1"],
  "claims": [
    {
      "id": "C1",
      "statement": "The supplied rational polynomials are equal.",
      "check": "polynomial_identity",
      "params": {"left": ["1/3", 2], "right": ["2/6", 2]},
      "depends_on": []
    }
  ]
}
```

IDs must be unique. References must resolve. There must be 1–256 claims and at
least one required root. `origin` is optional provenance metadata. Extra fields
are not evidence and do not alter verdicts. A `verdict` supplied by the caller is
ignored. Statements are descriptive labels: the tool validates **parameters**,
not the correspondence between prose and parameters. Human review must check that
translation and disclose undeclared premises. Unknown check names return UNRESOLVED.

| Check | Required parameters | Actual scope |
|---|---|---|
| `polynomial_identity` | `left`, `right`: coefficient lists, ascending degree | Equality in Q[n] after trimming trailing zero coefficients |
| `affine_power_identity` | `polynomial`, `slope`, `intercept`, `power`, `offset` | Compare to `(slope*n + intercept)^power + offset` by binomial expansion |
| `integer_volume` | `polynomial`, `scale`, `start`, `stop` | Exact integrality on the inclusive finite integer window; first counterexample retained |
| `cube_rotations` | `expected_count` | Count determinant +1 signed permutation matrices preserving cube vertices |
| `fano_automorphisms` | `expected_count` | Count all permutations preserving the Fano incidence lines |
| `order_divides` | `child_order`, `parent_order` | Positive integer divisibility only, never an embedding certificate |
| `permutation_group` | `degree`, `generators`, `expected_order`; optional `max_elements` | Explicit generated finite group, order, closure, inverse witnesses, commutativity |
| `obligation` | `needed`: nonempty list; optional `notes` | Always UNRESOLVED in v0.1, even if notes assert a proof |

Rational values must be integers or exact strings such as `"40/39"`. Floats and
booleans are rejected. Polynomials have at most 65 coefficients. Affine powers
are 0–64. Integrality scans cover at most 10,001 integers, with nonnegative start.
Permutations are lists mapping each `i` to `g[i]`, for `0 <= i < degree`.
Degree is 1–16; there are 1–16 generators; enumeration is capped at 256 elements.
Budget exhaustion yields UNRESOLVED. The implementation executes no input code.
It is not hardened as a public adversarial JSON service; use bounded local inputs.

The aggregate follows required roots and their declared dependencies. Any failing
premise makes a root FAIL; otherwise unresolved premises make it UNRESOLVED;
otherwise it passes. Cycles fail as invalid support structures. Other diagnostic
claims are retained and counted but do not determine the root verdict.

## Report fields

`schema_version`, `animal`, `version`, `target`, `required_claims`, `verdict`,
`counts`, `scope`, `independent_replication`, and `results` are always emitted for
valid manifests. File runs also include `input_sha256` and `checker_sha256`.
Each result contains ID, statement, check, verdict, evidence status, reason, and
evidence; non-circular results include dependency verdicts.

`demonstrated` means the specified local proposition was checked. It does not
mean the prose describes nature, that an unimplemented bridge was verified, or
that the result was independently replicated. An unresolved hypothesis is never
upgraded to proof merely for surviving these checks.

## Extending the operation

Add a new typed checker only with its definitions, limits, positive and adversarial
controls, and an updated version/freeze. A bridge cannot pass merely because a
filename, URL, hash, or human PASS label is present. Preserve previous reports;
record a contract amendment when domains, interpretations, or required roots change.
