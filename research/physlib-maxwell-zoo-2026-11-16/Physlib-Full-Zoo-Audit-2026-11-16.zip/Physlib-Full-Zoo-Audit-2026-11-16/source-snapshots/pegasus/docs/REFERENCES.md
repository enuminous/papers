# References and evidence boundaries

Accessed November 11, 2026 (America/Los_Angeles). These are reference checks,
not evidence that the source's hybrid has been constructed.

| ID | Primary / author source | Fact used here |
|---|---|---|
| R1 | [ATLAS of Finite Group Representations: Monster](https://brauer.maths.qmul.ac.uk/Atlas/v3/spor/M/) | Complete Monster order and the need for actual generators/representations |
| R2 | [ATLAS: Mathieu group M11](https://brauer.maths.qmul.ac.uk/Atlas/v3/spor/M11/) | M11 order 7920; explicit presentations and representations exist |
| R3 | [Nebe–Sloane Catalogue of Lattices: Leech](https://www.math.rwth-aachen.de/~Gabriele.Nebe/LATTICES/Leech.html) | Rank 24; lattice specified by mathematical data, not visual resemblance |
| R4 | [Doyle, Voce, Lim, Lo: Finite Projective Geometry, §3.1](https://www.homepages.ucl.ac.uk/~ucahbdo/FiniteProjectivePlanes.pdf) | Fano incidence automorphism group has order 168; a standard educational derivation |
| R5 | [John Baez: The Yang–Baxter Equation](https://math.ucr.edu/home/baez/braids/node4.html) | Braid generators and relations; distinction from extra permutation relations |
| R6 | [Andersen et al.: arXiv:2210.10255](https://arxiv.org/abs/2210.10255) | Example of an actual state, operation, and observation program for non-Abelian braiding |

The cube and Fano counts are also calculated locally from explicit finite objects.
No R1–R6 claim is used to establish the image's missing bridge maps. The complete
Monster factorization comes from R1; the supplied image is cropped at that line.

No source located in this bounded review establishes the stated Pegasus hybrid.
This is not an exhaustive novelty search or a finding that no such construction
could exist. The software's provenance/dependency checks and algebraic routines
overlap established practices. Novelty is limited here to the new named Zoo
operation and its particular implementation; scientific priority is unassessed.
