# PEGASUS

**Provenance-Enforced Geometric–Algebraic Synthesis Under Scrutiny**

*Let the hybrid fly. Make the bridges hold.*

A new Monolithic Zoo animal for auditing proposed constructions that combine
geometry, algebra, symmetry, topology, and physical interpretation. PEGASUS asks:
**Have the parts actually been connected by defined, checkable maps?**

The name is a seven-word backronym: **P**rovenance **E**nforced **G**eometric
**A**lgebraic **S**ynthesis **U**nder **S**crutiny.

The winged horse is the mascot; the fixed audit operation is the animal.
Its body represents a defined object, its wings the structures being attached,
and its joints the maps that must preserve the claimed properties.

**Version:** 0.1.0 · **Introduced:** November 11, 2026 · **Zoo ID:** `PEGASUS`
· **Roster status:** standalone extension; no global animal number assigned.

## What is here

- [Animal contract and mathematical specification](SPEC.md)
- [Frozen interpretation of the supplied image](sources/TRANSCRIPTION.md)
- [Source claim ledger](examples/source-claims.json) and [first audit](reports/FIRST_AUDIT.md)
- [Executable positive control](examples/toy-hybrid.json): a finite `C4 × C2` action
- [Machine-readable animal registration](animal.json)
- [Primary references and novelty boundary](docs/REFERENCES.md)
- [Input format, checks, and limits](docs/INPUT_FORMAT.md)
- Python standard-library checker, regression controls, and CI workflow

## First result

**The pictured speculative lattice/anyon/sporadic construction is UNRESOLVED.**
The finite control is **PASS within its explicitly limited scope**.

| Check | Verdict | Meaning |
|---|---|---|
| `8n³ + 12n² + 6n = (2n+1)³ − 1` | PASS | Exact polynomial identity |
| Dressed volume as a count of whole unit cubes | FAIL | At `n=1`, it is `80/3` |
| Ordinary cube has 24 proper rotations | PASS | Finite exact enumeration |
| Ordinary cube has only the identity proper symmetry | FAIL | Explicit diagnostic interpretation, not the undefined junction model |
| Fano incidence automorphism count | PASS | 168, independently enumerated |
| `7920` divides the reference Monster order | PASS | Necessary arithmetic condition only |
| Anyonic, non-orientable, Leech, and Monster bridges | UNRESOLVED | Required definitions and witnesses are missing |
| Explicit toy hybrid `C4 × C2` | PASS | Eight concrete permutations; no claim of new physics |

The first audit has **4 PASS, 2 FAIL, 8 UNRESOLVED** source/control rows.
The headline follows required root `H1`; diagnostic failures remain visible.
There is no average score that can hide a missing bridge.

## Run

Python **3.10+**. No runtime packages, credentials, or network connection needed.
Run these commands from the repository root:

```sh
python3 -m pegasus --verify-freeze
python3 -m unittest discover -s tests -v
python3 -m pegasus examples/toy-hybrid.json
python3 -m pegasus examples/source-claims.json
```

The last command intentionally exits **3**, meaning **UNRESOLVED**. Exit codes:
`0 = PASS`, `1 = FAIL`, `2 = invalid input`, `3 = UNRESOLVED`.
Use `--output path.json` to save a report. Diagnostics may contain FAIL rows even
when all selected required roots pass; always inspect the complete report.

`freeze.json` locks the implementation, operation contract, source image,
claim manifests, tests, and reference ledger with SHA-256 hashes. It is a local
reproducibility record, not an independent preregistration or proof of authorship.

## Evidence boundary

This is a bounded Python audit tool, **not a Lean formalization**, a general
theorem prover, or a physical validation of EFMW, LDT, S-DMT, or the image's taxonomy.
Claims are checked through typed parameters; natural-language statements and
undeclared dependencies require human review. Unknown operations, unimplemented
bridges, and exhausted enumeration budgets remain UNRESOLVED.

The tool and its tests were developed together. The supplied image is the first
development case; no blind benchmark, independent replication, or empirical
performance advantage is claimed. The standard mathematics used here is not
presented as a new discovery.

The image describes its inspiration as being in the style of `@Voltardark`.
That attribution is preserved; authorship, endorsement, and the original thread
have not been independently established. The full supplied image is retained
as [source evidence](sources/pegasus-source.jpeg), including its speculative label.

Related work: [Monolithic Zoo Lean4](https://github.com/enuminous/Monolithic-Zoo-Lean4)
· [TORTOISE](https://github.com/enuminous/Tortoise)
· [EFMW](https://github.com/enuminous/EFMW)
· [Papers](https://github.com/enuminous/papers).
These links indicate context, not verified integration or mathematical equivalence.
