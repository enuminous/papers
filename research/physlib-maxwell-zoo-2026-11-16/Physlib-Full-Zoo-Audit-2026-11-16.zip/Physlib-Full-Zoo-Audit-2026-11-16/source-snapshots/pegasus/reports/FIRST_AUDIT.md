# PEGASUS first audit — November 11, 2026

**Root verdict: UNRESOLVED.** The supplied image does not yet specify a checkable
mixed lattice/anyon/sporadic construction. This is an evidence limitation, not a
proof of impossibility. Two explicit diagnostic readings are contradicted.

Target: [frozen source interpretation](../sources/TRANSCRIPTION.md).
Inputs: [source claim manifest](../examples/source-claims.json).
Operation: [PEGASUS v0.1.0](../SPEC.md).
Machine output: [complete source report](source-claims.json).

| ID | Operation / tested claim | Verdict | Reason or witness | Evidence status |
|---|---|---|---|---|
| A1 | Binomial expansion of the volume polynomial | PASS | Exact coefficients agree with `(2n+1)^3 - 1` | Demonstrated algebraically |
| G1 | Literal whole-unit-cube count | FAIL | `n=1` gives `80/3` | Rejected interpretation |
| S1 | Ordinary cube has 24 proper rotations | PASS | Exhaustive signed-permutation enumeration | Demonstrated finite computation |
| S2 | Ordinary cube has only the identity proper symmetry | FAIL | Actual count is 24 | Rejected diagnostic interpretation |
| A2 | Fano-plane automorphism count | PASS | 168 of 5040 permutations preserve incidence | Demonstrated finite computation |
| A3 | M11 order divides reference Monster order | PASS | `7920` divides the full reference order | Demonstrated arithmetic only |
| G2 | Geometric meaning of dressed volume | UNRESOLVED | Domain, measure, and prefactor derivation missing | Unresolved |
| S3 | Junction non-orientability | UNRESOLVED | Cell complex, gluing maps, obstruction missing | Unresolved |
| S4 | Anyonic exchange statistics | UNRESOLVED | State space and braid/exchange model missing | Unresolved |
| A4 | Leech-sector coupling | UNRESOLVED | Lattice and structure-preserving coupling data missing | Unresolved |
| A5 | M11/Fano action on common object | UNRESOLVED | Group selection, object, and action unspecified | Unresolved |
| A6 | Monster subquotient residue | UNRESOLVED | No H, normal N, or checked quotient identification | Unresolved |
| U1 | EFMW process dynamics | UNRESOLVED | State law, observable, and test contract missing | Unresolved |
| H1 | Full pictured hybrid | UNRESOLVED | Required bridge obligations remain unresolved | Unresolved |

The first manifest contains **4 PASS, 2 FAIL, 8 UNRESOLVED** rows. H1 is the required
root. G1 and S2 are separate interpretation diagnostics, so they do not silently
convert the unspecified custom construction into a disproved ordinary-cube model.

## What survives

The polynomial identity is exact. Standard cube and Fano symmetry objects can be
enumerated reproducibly. The reference group-order divisibility check succeeds.
None of those facts supplies the missing hybrid construction.

The source's speculative taxonomy remains available as creative framing.
Its claims of physical statistics, custom topology, and mixed group/lattice
structure remain hypotheses pending explicit definitions and independent evidence.

## Positive control

[PEGASUS-T0](../examples/toy-hybrid.json) supplies a cube quarter-turn and a
separate two-label wing exchange. [Its report](toy-hybrid.json) verifies an
abelian permutation group with eight elements, realizing `C4 × C2`.
**PASS for that finite action only.** It is a standard disconnected product
control and supplies no evidence for H1 or for emergent coupling.

## Validation and provenance

- Local runtime: Python 3.12.14.
- `python3 -m unittest discover -s tests -v`: **26 tests passed**.
- `python3 scripts/replay.py`: both saved JSON reports reproduced exactly;
  source target exits 3 and toy control exits 0.
- Source image, contract, checker, tests, and inputs are hashed in
  [freeze.json](../freeze.json). Machine reports carry input and checker hashes.
- Computations use exact integer/rational operations. No tolerance was fitted.
- This was a development case with a local freeze, not a sealed confirmatory run.
- No independent reviewer, empirical experiment, Lean build, or external
  replication was performed. A CI workflow replays these checks when available;
  CI is execution evidence, not independent scientific replication.

## Next discriminating submission

Provide one actual coupling map with a typed domain/codomain, generators or lattice
data, and a named invariant to preserve. Freeze the proposed checker and the
uncoupled control before running it. A checked violation fails the corresponding
claim; a missing or uncheckable map remains unresolved. A pass establishes only
the explicit construction and scope that were checked.
