"""Replay saved reports and assert expected CLI exit codes without shell masking."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
for stem, expected_code in (("source-claims", 3), ("toy-hybrid", 0)):
    completed = subprocess.run([sys.executable, "-m", "pegasus", f"examples/{stem}.json"],
                               cwd=ROOT, capture_output=True, text=True, check=False)
    if completed.returncode != expected_code:
        raise SystemExit(f"{stem}: unexpected exit {completed.returncode}: {completed.stderr}")
    actual = json.loads(completed.stdout)
    saved = json.loads((ROOT / "reports" / f"{stem}.json").read_text())
    if actual != saved:
        raise SystemExit(f"{stem}: saved report differs from replay")
    print(f"{stem}: exact replay; {actual['verdict']}; exit {completed.returncode}")
