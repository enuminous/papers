# Physlib Maxwell full Zoo audit — 2026-11-16

Start with `report/Physlib_Full_Zoo_Audit_2026-11-16.md`.

The four Physlib Maxwell theorems passed the bounded local proof audit. The pinned Zoo release failed its own README checksum gate. All 53 accounted-for animal names have explicit dispositions; most fixed operations require datasets outside this mathematical target. Nothing here validates EFMW as physics.

## Contents

- `report/`: full report, complete animal ledger, frozen plan, source/dependency manifests, Lean/Python harnesses, results, proposed checksum patch.
- `logs/`: original successful and failed executions. Intentional negative-control errors and failed harness-development attempts are preserved.
- `source-snapshots/`: original Physlib import-closure sources, selected Zoo/engine/PEGASUS source and license files, exact Git revisions in `SOURCE_PINS.json`.
- `BUNDLE_SHA256.json`: local integrity hashes for the archived files.

The `report/controls/` files deliberately contain forbidden axioms, placeholders or false goals. They test rejection; they are not proofs or proposed Physlib contributions. Only the passing final `ZeroWitness.lean` is a new mathematical witness in this audit.

## Verify the bundle

```sh
python3 report/replay.py --check-only
```

## Replay the audit

Use an extracted copy with Git, Python 3.10+ and [elan](https://github.com/leanprover/elan) available. The command clones the four public repositories at their exact revisions and downloads the pinned toolchains and dependency caches. Allow several gigabytes for build artifacts.

```sh
python3 report/replay.py
```

`replay-logs/` records command exit codes and outputs. Before running, the script preserves the original `report/` and `logs/` under `original-audit/`, then reruns the final corrected harnesses. The known Zoo `verify.py` README failure is explicitly expected and retained, not repaired. No upstream publication is performed.

`report/ZOO_README_MANIFEST.patch` is a proposed one-line repair against Zoo commit `8b22841ffcf44e41451e7696335bf6a6ae8f222e`. Review the README change before applying it. It has not been applied to the audited checkout.

The source snapshots are evidence excerpts, not complete buildable copies. Replay uses the full Git repositories. The compiled dependencies were cached; the target Maxwell module and the local witness were freshly elaborated. The audit does not claim a from-source rebuild of every dependency.
