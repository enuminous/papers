"""Execute only fixed Zoo operations with honest target/evidence inputs."""
import hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'report'
sys.path.insert(0,str(ROOT/'engine'))
from research_engine.kernels import evaluate

def dump(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')

module_path='Physlib/Electromagnetism/ThreeDimension/MaxwellEquations.lean'
history=subprocess.check_output(['git','log','--first-parent','--format=%H %ct','--',module_path],cwd=ROOT/'target').decode().splitlines()[::-1]
head=subprocess.check_output(['git','show','-s','--format=%H %ct','HEAD'],cwd=ROOT/'target').decode().strip()
if head not in history: history.append(head)
events=[]
for i,row in enumerate(history):
    sha,time=row.split()
    events.append({'id':i,'time':int(time),'status':'active' if i==len(history)-1 else 'superseded',
                   'supersedes':None if i==0 else i-1,
                   'provenance':f'https://github.com/leanprover-community/physlib/blob/{sha}/{module_path}'})
inputs={'events':events,'start':len(events)-1,'fuel':len(events)+1}
dump('ELEPHANT-input.json',inputs)
result=evaluate('ELEPHANT',inputs)
passed=(result['termination']=='origin' and [x['id'] for x in result['lineage']]==list(range(len(events)-1,-1,-1)) and result['current']==[events[-1]])
dump('ELEPHANT-result.json',{'native_result':result,'audit_verdict':'PASS' if passed else 'FAIL',
     'scope':'First-parent source-change history plus pinned snapshot anchor. Active means selected for this audit, not newest upstream. Not the whole Git DAG or theorem validity.'})
assert passed

circus={
 'animal':'CIRCUS','decision':'N/A',
 'scope':'External evidentiary closure of this audit, not validity of Maxwell equations',
 'pipeline':[{'stage':s,'provenance_status':'documented'} for s in ['definition','data_selection','labels','scoring','validation']],
 'dependencies':[{'id':'source-and-derived-logs','materiality':'material','feedback':False,
                 'note':'One dependent evidence chain; no multiplication into independent confirmations.'}],
 'risks':[{'id':'statistical-leakage','materiality':'nonmaterial','status':'na',
           'note':'No predictive performance or empirical generalization is claimed.'}],
 'independent_checks':[{'id':'external-semantic-review-of-this-audit','status':'pending','frozen':False,'independently_sourced':False}],
 'note':'No external review has occurred. Local fixture tests and local Lean replay are not independent scientific replication.'}
dump('CIRCUS-input.json',circus)
spec=importlib.util.spec_from_file_location('circus_frozen',OUT/'extension-sources/Circus.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
decision=mod.decide(circus)
dump('CIRCUS-result.json',{'native_decision':decision,'audit_verdict':'UNRESOLVED',
     'reason':'Required externally independent check is pending; native N/A is retained. No mathematical refutation follows.'})
assert decision=='N/A'

pegasus={'schema_version':'pegasus-claims/1','target':'Physlib covariant-to-3D Maxwell bridge at 892e8fcba8af5ec691ca7a8ad82ee5dbe3180b17',
 'required_claims':['MAXWELL'],
 'claims':[
  {'id':'VARIATION','statement':'Smooth electromagnetic Lagrangian has the stated variational gradient.',
   'check':'obligation','params':{'needed':['A checker for the actual Lean theorem and its full hypotheses'],
    'notes':'Physlib provides lagrangian_hasVarGradientAt_gradLagrangian. PEGASUS v0.1 cannot import Lean certificates.'},'depends_on':[]},
  {'id':'INHOMOGENEOUS','statement':'IsExtrema and smoothness imply electric Gauss and Ampere laws.',
   'check':'obligation','params':{'needed':['Lean verification and semantic matching of the covariant-to-3D map']},'depends_on':['VARIATION']},
  {'id':'HOMOGENEOUS','statement':'Smooth potential definitions imply magnetic Gauss and Faraday laws.',
   'check':'obligation','params':{'needed':['Lean verification of divergence/curl and time-derivative identities']},'depends_on':[]},
  {'id':'MAXWELL','statement':'All four documented differential laws hold under the printed hypotheses.',
   'check':'obligation','params':{'needed':['A supported proof-certificate bridge in this fixed PEGASUS version']},
   'depends_on':['INHOMOGENEOUS','HOMOGENEOUS']}]}
dump('PEGASUS-input.json',pegasus)
proc=subprocess.run([sys.executable,'-m','pegasus',str(OUT/'PEGASUS-input.json'),'--output',str(OUT/'PEGASUS-result.json')],cwd=ROOT/'pegasus',capture_output=True,text=True)
(ROOT/'logs/pegasus-target.log').write_text(proc.stdout+proc.stderr)
assert proc.returncode==3,(proc.returncode,proc.stdout,proc.stderr)
assert json.loads((OUT/'PEGASUS-result.json').read_text())['verdict']=='UNRESOLVED'
dump('TARGET_OPERATION_RUN.json',{'ELEPHANT':'PASS: bounded provenance only','CIRCUS':'UNRESOLVED (native N/A): no external review','PEGASUS':'UNRESOLVED: no implemented Lean bridge checker'})
print('ELEPHANT: PASS (provenance only); CIRCUS: native N/A; PEGASUS: UNRESOLVED.')
