"""Supplementary source inventory; not a Lean parser or a proof checker."""
import hashlib, json, re, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / 'target'
OUT = ROOT / 'report'
MODULE = 'Physlib.Electromagnetism.ThreeDimension.MaxwellEquations'

def uncomment(s):
    out=[]; i=0; depth=0; string=False
    while i<len(s):
        if depth:
            if s[i:i+2]=='/-': depth+=1; i+=2
            elif s[i:i+2]=='-/': depth-=1; i+=2
            else:
                if s[i]=='\n': out.append('\n')
                i+=1
        elif string:
            if s[i]=='\\': i+=2
            elif s[i]=='"': string=False; out.append(' '); i+=1
            else:
                if s[i]=='\n': out.append('\n')
                i+=1
        elif s[i:i+2]=='/-': depth=1; out.append(' '); i+=2
        elif s[i:i+2]=='--':
            j=s.find('\n',i); i=len(s) if j<0 else j
        elif s[i]=='"': string=True; out.append(' '); i+=1
        else: out.append(s[i]); i+=1
    return ''.join(out)

def imports(path):
    return re.findall(r'(?m)^\s*(?:(?:public|private|meta)\s+)*import\s+(?:all\s+)?([\w.]+)',uncomment(path.read_text()))

closure={}; external=set(); pending=[MODULE]
while pending:
    m=pending.pop()
    if m in closure or m in external: continue
    p=TARGET/Path(*m.split('.')).with_suffix('.lean')
    if not p.exists(): external.add(m); continue
    deps=imports(p); closure[m]=deps; pending.extend(deps)
files=subprocess.check_output(['git','ls-files','-z'],cwd=TARGET).decode().split('\0')
inventory=[]; flags=[]
for f in filter(None,files):
    p=TARGET/f
    if not p.is_file(): continue
    inventory.append({'path':f,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    if p.suffix=='.lean':
        for i,line in enumerate(uncomment(p.read_text()).splitlines(),1):
            for word in re.findall(r'\b(?:sorry|admit|axiom|native_decide|unsafe)\b',line):
                flags.append({'path':f,'line':i,'token':word,'code':line.strip()})
closure_paths={m.replace('.','/')+'.lean' for m in closure}
result={'root_module':MODULE,'tracked_files':inventory,'local_import_closure':closure,
        'external_import_frontier':sorted(external),'lexical_flags':flags,
        'closure_lexical_flags':[x for x in flags if x['path'] in closure_paths],
        'limitation':'Textual inventory only. Comment/string filtering is not a full Lean parser. Lexical native_decide hits are not automatically theorem dependencies.'}
(OUT/'SOURCE_INVENTORY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'tracked_files':len(inventory),'local_import_closure':len(closure),
                  'external_import_frontier':len(external),'lexical_flags':len(flags),
                  'closure_lexical_flags':result['closure_lexical_flags']},indent=2))
