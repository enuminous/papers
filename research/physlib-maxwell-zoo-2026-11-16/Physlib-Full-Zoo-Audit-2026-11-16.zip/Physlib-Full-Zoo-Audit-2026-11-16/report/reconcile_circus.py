"""Reconcile the observed tool-integrity failure; preserve the earlier pending gate."""
import importlib.util,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
report=json.loads((OUT/'CIRCUS-input.json').read_text())
manifest=json.loads((OUT/'ZOO_MANIFEST_CHECK.json').read_text())
assert [r['file'] for r in manifest['mismatches']]==['README.md']
report['decision']='FAIL'
report['risks'].append({'id':'pinned-zoo-release-integrity','materiality':'material','status':'present',
 'evidence':'ZOO_MANIFEST_CHECK.json and logs/zoo-static.log',
 'note':'The frozen audit tool release does not pass its own static manifest gate. Mismatch is limited to README.md; no changed proof source was found. This blocks a blanket audit-tool integrity PASS, not the four Physlib theorem results.'})
(OUT/'CIRCUS-final-input.json').write_text(json.dumps(report,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('circus_frozen',OUT/'extension-sources/Circus.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
native=mod.decide(report);assert native=='FAIL'
(OUT/'CIRCUS-final-result.json').write_text(json.dumps({'native_decision':native,'audit_verdict':'FAIL',
 'scope':'Integrity of the pinned Zoo release used as an audit instrument; not a mathematical refutation of Physlib',
 'reason':'Known material release-manifest failure retained under the frozen FAIL-precedence rule. Independent external review also remains pending.'},indent=2)+'\n')
print('CIRCUS final: FAIL for audit-tool release integrity; original N/A retained.')
