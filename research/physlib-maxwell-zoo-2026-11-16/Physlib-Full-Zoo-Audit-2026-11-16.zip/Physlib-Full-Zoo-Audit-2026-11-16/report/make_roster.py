"""Account for the frozen roster without manufacturing target measurements."""
import csv, inspect, json, re, sys
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'report'
sys.path.insert(0,str(ROOT/'engine'))
from research_engine.kernels import KERNELS,describe
from research_engine.catalog import Catalog
names=re.findall(r'"([A-Z]+)"',(ROOT/'zoo/Registry.lean').read_text())
assert len(names)==len(set(names))==46
coverage=json.loads((ROOT/'zoo/coverage.json').read_text())
ranked=Catalog().ranked
missing={
 'TURTLE':'A calibrated invariant score and independent evidence groups are not supplied. Source, CI and local replay share an evidence chain; no invented numeric support score.',
 'MAGPIE':'Groundedness/provenance/contradiction score measurements and a prior observation have no validated mapping for this Lean target.',
 'WEASEL':'The port filters supplied numerical findings; it does not search proofs. No defined changed-key/severity/cost measurement for a Physlib counterexample is supplied. Harness mutations are controls, not Physlib defects.',
 'MOLE':'No measured latent-degradation or coverage indicators for this static proof target; a textual source count is not an accepted substitute.',
 'LYNX':'No validated novelty-distance, rarity, rediscovery, replication and yield measurements. A literature/definition comparison is reported separately without fabricating scores.'}
why={
 'TORTOISE':'No probabilistic forecasts, ground-truth outcomes or Brier scores are part of this target.',
 'CAT':'No measured performance-loss ablation experiment is part of this theorem audit.',
 'BAT':'No candidate/placebo forecast experiment or Brier comparison is part of this target.',
 'HEDGEHOG':'No development/heldout predictive environments or measured gains are part of this target.',
 'CROCODILE':'No treated/control pre/post empirical outcome data or causal intervention is claimed.',
 'WOLF':'No time series of monitoring channels and no instantaneous/previous EMA states.',
 'CHAMELEON':'No adaptation/noise distance experiment is claimed.',
 'JELLYFISH':'No dynamical health graph, stress measurements or propagation experiment.',
 'BEAVER':'No deployed intervention, collateral measurement or rollback episode.',
 'MANTIS':'No precursor time series, calibration baseline or z scores.',
 'BISON':'No demand/capacity queue system is being tested.',
 'SALMON':'No weighted evidence-flow network or unresolved-mass model is supplied; theorem dependencies are not asserted to be calibrated weights.',
 'ORCA':'No multi-actor operational handoff experiment or recipient acknowledgment is in scope.',
 'HORSE':'No human workload, attention or fatigue measurements.',
 'TERMITE':'No interacting-agent simulation or neighbor-state snapshot.',
 'PHOENIX':'No recovery episode, fidelity measurements or finite stability window.',
 'COBRA':'No longitudinal goal/proxy divergence and confidence measurements.',
 'WHALE':'No historical signal series or baseline deviation experiment.',
 'FALCON':'No hazard event, alarm, intervention or reaction times.',
 'RHINO':'No measured pre/post-shock performance experiment.',
 'BONOBO':'No multi-agent utilities, fairness or cooperation outcome experiment.',
 'AXOLOTL':'No damage/adaptation episode or measured recovery costs.',
 'BUTTERFLY':'No nonlinear cascade/layer simulation is being claimed.'}
rows=[]
for n in names:
    spec=describe(n); src=next(x for x in coverage if x['module'].upper()==n)
    if n=='ELEPHANT':
        status='PASS';reason='Executed on actual selected file history plus pinned snapshot anchor; lineage reaches origin and preserves all five selected records. Provenance only.';run=True
        criterion='Origin termination; exactly one active pinned record; lineage equals every supplied event in reverse chronological order.'
    elif n in missing:
        status='UNRESOLVED';reason=missing[n];run=False
        criterion='Provide a justified mapping and required real measurements before interpreting the native operation; none may be fabricated.'
    else:
        status='NOT_APPLICABLE';run=False
        reason=('Only retrospective rank aggregation of precomputed feature columns is ported; no ranked dataset or feature-extraction contract exists for the four Maxwell proofs.' if n in ranked else why[n])
        criterion='Requires an in-domain dataset satisfying the fixed schema. No target PASS criterion exists in the absence of that experiment.'
    rows.append({'animal':n,'group':'core-46','purpose_and_transformation':spec['implemented_scope'],
        'inputs':spec['parameters'],'operation_source':inspect.getsource(KERNELS[n][0]),
        'rank_components':ranked.get(n),'native_output':'Exact dictionary returned by the frozen operation_source; no universal pass/fail output is inferred.',
        'criterion':criterion,'target_executed':run,'target_verdict':status,'reason':reason,
        'fixture_evidence':'Core Python test suite (22 methods, including all 90 reference comparisons); current Zoo Lean build and 90-reference runner. Fixtures are not target results.',
        'formalization_source':src})
exts=[
 ('CHIMERA','Ordered failure-mode tags with fallback U, metadata and K recovery-map requirements.',
  'Event object/interaction; seven mode flags and optional provenance, recovery map, key/note.',
  'Nonempty ordered tags; K requires its declared prerequisites. Supplied flag truth remains external.',
  'NOT_APPLICABLE','No in-domain failure-mode event and recovery-map record is asserted for these theorems.'),
 ('CIRCUS','Report gate with FAIL precedence; provenance, dependencies, risks and independent-check lists.',
  'CIRCUS-final-input.json; declared audit pipeline, pending external review, observed release-manifest failure.',
  'Native PASS needs no open material gate and complete frozen independently sourced checks; explicit native N/A is retained.',
  'FAIL','Final native FAIL: the Zoo release fails its own README checksum gate. Earlier native N/A retained. This applies to audit-tool integrity, not Maxwell validity.'),
 ('MONSTER','Robustness gate requiring preregistration, matched baseline, complete mandatory conditions and failure-boundary records.',
  'Preregistration/protocol; metric tolerance/direction; baseline; candidate/baseline condition outcomes; failure boundaries.',
  'Eligible, complete and no violating mandatory condition/boundary => native PASS; otherwise FAIL or N/A as source specifies.',
  'NOT_APPLICABLE','No preregistered empirical robustness benchmark or matched performance data exists in this audit.'),
 ('WOODPECKER','Validated ablation loss against exact necessity/contribution thresholds.',
  'Baseline/ablated values, direction, epsilon, contribution fraction, preserved conditions, violations, preregistration and leakage flags.',
  'Fixed validity and loss thresholds classify necessary/contributory/redundant/indeterminate; labels do not prove mathematical hypothesis necessity.',
  'NOT_APPLICABLE','No loss-valued empirical ablation; removing a theorem hypothesis is a different formal task and is not silently substituted.'),
 ('NIGHTINGALE','ALE/bootstrap explanation-tree support/effect/stability/depth stopping rules; formal coverage is a decision-stage projection.',
  'Fitted model, predictor/response data, local-support bins, effect tolerance, bootstrap information, maximum depth.',
  'Fixed stopping criteria applied to genuine explanatory data; branch certificates do not validate the ALE/statistical pipeline.',
  'NOT_APPLICABLE','No fitted predictor, explanation dataset or bootstrap experiment is part of the Maxwell audit.'),
 ('PEGASUS','Typed claim checks and dependency propagation without caller-certified PASS labels.',
  'PEGASUS-input.json: variational, inhomogeneous, homogeneous and root bridge obligations.',
  'Every required root and prerequisite must be established by a supported exact checker; missing checker => UNRESOLVED.',
  'UNRESOLVED','Executed on four claims: fixed v0.1 has no Lean-certificate checker. Separate Lean replay cannot be passed off as a PEGASUS capability.'),
 ('HUMMINGBIRD','Unresolved: a versioned fixed contract and executable source were not located.',
  'Required: canonical source URL/commit, schema, transformation and decision contract.',
  'No operation can be invented from an animal name or earlier prose description.',
  'UNRESOLVED','Not in the pinned 46-name registry or five-extension manifest. Exact repository lookup returned 404 and scoped repository searches returned no match. No global absence is asserted.')]
for n,purpose,inputs,criterion,status,reason in exts:
    rows.append({'animal':n,'group':'standalone-extension' if n=='PEGASUS' else 'unlocated-contract' if n=='HUMMINGBIRD' else 'formalized-extension',
      'purpose_and_transformation':purpose,'inputs':inputs,'criterion':criterion,'target_executed':n in ['CIRCUS','PEGASUS'],
      'target_verdict':status,'reason':reason,
      'fixture_evidence':'No implementation located' if n=='HUMMINGBIRD' else 'PEGASUS 26 tests and 17 frozen file hashes' if n=='PEGASUS' else '643 decision, 1432 complete-record and 2100 threshold certificates across five extensions; exact coverage differs by operation. See logs.'})
assert len(rows)==53
(OUT/'FULL_ROSTER.json').write_text(json.dumps(rows,indent=2)+'\n')
with (OUT/'FULL_ROSTER.csv').open('w',newline='') as f:
    keys=['animal','group','purpose_and_transformation','target_executed','target_verdict','reason','criterion']
    w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
md=['# Full Zoo roster accounting','',
    '46 registered core animals + five formalized extensions + standalone PEGASUS + an unresolved HUMMINGBIRD contract lookup. This accounting does not assign a new global roster number. Only applicable fixed operations are executed on target data. Fixtures and source-certificate counts are tool validation, not confirmations of Physlib.','',
    '| Animal | Target disposition | Fixed operation and reason |','|---|---|---|']
for r in rows:
    md.append('| '+r['animal']+' | '+r['target_verdict']+' | '+(r['purpose_and_transformation']+' '+r['reason']).replace('|','/')+' |')
md+=['','Machine-readable schemas, exact selected kernel implementations, source coverage and criteria are in `FULL_ROSTER.json` and `CORE_SCHEMAS.json`.','']
(OUT/'FULL_ROSTER.md').write_text('\n'.join(md))
print(json.dumps({'accounted':len(rows),'target_executed':sum(x['target_executed'] for x in rows),'dispositions':dict(Counter(x['target_verdict'] for x in rows))},indent=2))
