"""Conventional SI dimension bookkeeping; not a claim about Lean unit typing."""
import json
from pathlib import Path
# Exponents in (mass, length, time, current). Assigned physical interpretation.
E=(1,1,-3,-1);B=(1,0,-2,-1);rho=(0,-3,1,1);J=(0,-2,0,1)
eps=(-1,-3,4,2);mu=(1,1,-2,-2);dx=(0,-1,0,0);dt=(0,0,-1,0)
def add(*xs): return tuple(map(sum,zip(*xs)))
def neg(x): return tuple(-a for a in x)
rows=[('electric Gauss',add(dx,E),add(rho,neg(eps))),
      ('Ampere current',add(dx,B),add(mu,J)),
      ('Ampere displacement',add(dx,B),add(mu,eps,dt,E)),
      ('Faraday',add(dx,E),add(dt,B)),
      ('c squared', (0,2,-2,0),neg(add(eps,mu)))]
out={'basis':['mass','length','time','current'],
 'scope':'Manual conventional SI interpretation of the printed equations, checked by exact integer bookkeeping. Physlib FreeSpace stores positive real parameters; this is not a Lean theorem about dimensionful quantities.',
 'checks':[{'check':n,'lhs':a,'rhs':b,'verdict':'PASS' if a==b else 'FAIL'} for n,a,b in rows]}
assert all(a==b for _,a,b in rows)
Path(__file__).with_name('DIMENSION_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print('5 exact dimension equalities passed under the stated SI interpretation.')
