"""Quarantined rejection controls. These are not changes to Physlib."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'report';LOG=ROOT/'logs'
source=(OUT/'Audit.lean').read_text()
# Keep all four real-root axiom checks plus the identical control scanner.
# Omit repeated dependency-graph logging, which is not part of the acceptance gate.
start=source.index('    let direct :=')
stop=source.index('  -- The same strict scanner')
source=source[:start]+source[stop:]
cases=[
 ('valid','theorem AuditProbe.good : (1 : Nat) = 1 := by rfl',None),
 ('public_axiom','axiom AuditProbe.bad : False','AuditProbe.bad'),
 ('private_axiom','namespace AuditProbe\nprivate axiom bad : False\nend AuditProbe','bad'),
 ('placeholder','theorem AuditProbe.bad : False := by sorry','sorryAx'),
 ('native','theorem AuditProbe.good : (1 : Nat) = 1 := by native_decide','native_decide'),
 ('false_arithmetic','theorem AuditProbe.bad : (0 : Nat) = 1 := by decide','ELABORATION_ERROR')]
suffix='-native-v2' if sys.argv[1:]==['--only-native'] else ''
if suffix: cases=[c for c in cases if c[0]=='native']
controls=OUT/'controls';controls.mkdir(exist_ok=True)
manifest=[]
for name,decl,expected in cases:
    content=source.replace('-- CONTROL_INSERTION_POINT',decl)
    p=controls/(name+'.lean');p.write_text(content)
    manifest.append({'case':name,'file':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(content.encode()).hexdigest(),'expected':expected})
(OUT/('CONTROL_FREEZE'+suffix+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
env=os.environ.copy();env['ELAN_HOME']=str(ROOT/'toolchains');env['PATH']=str(ROOT/'toolchains/bin')+os.pathsep+env['PATH']
results=[]
for row in manifest:
    proc=subprocess.run(['lake','env','lean',str(ROOT/row['file'])],cwd=ROOT/'target',env=env,capture_output=True,text=True,timeout=180)
    text=proc.stdout+proc.stderr;log=LOG/('target-control-'+row['case']+suffix+'.log');log.write_text(text)
    if row['expected'] is None:
        passed=proc.returncode==0 and 'STRICT_AXIOM_AUDIT_PASS roots=4, controls=1' in text
    elif row['expected']=='ELABORATION_ERROR':
        passed=proc.returncode!=0 and 'error:' in text and 'decide' in text
    else:
        passed=proc.returncode!=0 and 'Unapproved axiom' in text and row['expected'] in text
    result={**row,'exit_code':proc.returncode,'control_passed':passed,'log':str(log.relative_to(ROOT))}
    results.append(result)
    (OUT/('CONTROL_RESULTS'+suffix+'.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(row['case'],'PASS' if passed else 'FAIL','exit',proc.returncode,flush=True)
assert all(r['control_passed'] for r in results)
