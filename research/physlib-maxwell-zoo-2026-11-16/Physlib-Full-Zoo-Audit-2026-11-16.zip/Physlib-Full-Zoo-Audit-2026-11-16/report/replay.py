"""Reproduce the pinned audit in an extracted bundle. Requires git, elan and Python 3.10+."""
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PINS={
 'target':('leanprover-community/physlib','892e8fcba8af5ec691ca7a8ad82ee5dbe3180b17'),
 'zoo':('enuminous/Monolithic-Zoo-Lean4','8b22841ffcf44e41451e7696335bf6a6ae8f222e'),
 'engine':('enuminous/EFMW_Post156_Zoo_Audit','fd4ac30ffdbb44c78e7ea69e2424beaa9f3fdb93'),
 'pegasus':('enuminous/Pegasus','41d57615f16c43ea8858e35cd1250d44c3c7df97')}
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--check-only',action='store_true',help='Check bundled file hashes; do not clone or run builds')
args=parser.parse_args()
manifest=ROOT/'BUNDLE_SHA256.json'
if manifest.exists():
    for name,digest in json.loads(manifest.read_text()).items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    print('Bundled byte hashes match. This is local consistency, not independent authentication.',flush=True)
if args.check_only: raise SystemExit(0)
original=ROOT/'original-audit'
if not original.exists():
    original.mkdir()
    for name in ['report','logs']:
        if (ROOT/name).exists(): shutil.copytree(ROOT/name,original/name)
env=os.environ.copy()
local=ROOT/'toolchains/bin'
if (local/'elan').exists():
    env['ELAN_HOME']=str(ROOT/'toolchains');env['PATH']=str(local)+os.pathsep+env['PATH']
assert shutil.which('elan',path=env['PATH']),'Install elan from https://github.com/leanprover/elan first.'
logdir=ROOT/'replay-logs';logdir.mkdir(exist_ok=True);ledger=[]
def run(label,argv,cwd=ROOT,expected=0):
    print(label,flush=True);start=time.time()
    with (logdir/(label+'.log')).open('w') as f:
        p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    ledger.append({'label':label,'argv':argv,'cwd':str(cwd),'exit':p.returncode,'expected_exit':expected,'seconds':time.time()-start})
    (logdir/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n')
    assert p.returncode==expected,(label,p.returncode,expected)
for directory,(repo,sha) in PINS.items():
    dest=ROOT/directory
    if not dest.exists():
        run('clone-'+directory,['git','clone','https://github.com/'+repo+'.git',str(dest)])
        run('pin-'+directory,['git','checkout','--detach',sha],dest)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dest).decode().strip()==sha
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=dest).strip()
for version in ['4.35.0','4.19.0']:
    run('lean-'+version,['elan','toolchain','install','leanprover/lean4:v'+version])
py=shutil.which('python3')
run('core-tests',[py,'-m','unittest','discover','-s','research_engine/tests','-v'],ROOT/'engine')
run('pegasus-tests',[py,'-m','unittest','discover','-s','tests','-v'],ROOT/'pegasus')
run('pegasus-freeze',[py,'-m','pegasus','--verify-freeze'],ROOT/'pegasus')
# A known failure is reproduced, not silently converted to a passing integrity result.
run('zoo-static-EXPECTED-FAIL',[py,'verify.py'],ROOT/'zoo',expected=1)
assert 'AssertionError: README.md' in (logdir/'zoo-static-EXPECTED-FAIL.log').read_text()
run('zoo-build',['lake','build'],ROOT/'zoo')
run('zoo-executables',['lake','build','zoo46','regression'],ROOT/'zoo')
run('zoo-reference-fixtures',['lake','exe','regression'],ROOT/'zoo')
run('zoo-axioms',['lake','env','lean','-DwarningAsError=true','Audit.lean'],ROOT/'zoo')
run('zoo-controls',[py,'scripts/test_axiom_audit.py'],ROOT/'zoo')
for script in ['extension_fixtures','report_fixtures','threshold_fixtures']:
    run('zoo-'+script,[py,'scripts/'+script+'.py'],ROOT/'zoo')
for cert in ['SourceReportFixtures','ThresholdFixtures']:
    run('zoo-'+cert,['lake','env','lean','-DwarningAsError=true','.lake/'+cert+'.lean'],ROOT/'zoo')
run('target-cache',['lake','exe','get_cache','--no-alpha'],ROOT/'target')
run('target-build',['lake','build','Physlib.Electromagnetism.ThreeDimension.MaxwellEquations'],ROOT/'target')
run('target-fresh',['lake','env','lean','-Dweak.says.verify=true','-DwarningAsError=true','Physlib/Electromagnetism/ThreeDimension/MaxwellEquations.lean'],ROOT/'target')
run('target-default-build',['lake','build','-KCI','--iofail'],ROOT/'target')
run('target-axioms',['lake','env','lean','../report/Audit.lean'],ROOT/'target')
run('target-zero-witness',['lake','env','lean','-DwarningAsError=true','../report/ZeroWitness.lean'],ROOT/'target')
run('target-controls',[py,'report/test_target_scanner.py'])
run('target-pseudo',['lake','exe','pseudo_lint','Physlib','QuantumInfo'],ROOT/'target')
for script in ['source_inventory','dimensions','run_target_operations','reconcile_circus','make_roster']:
    run(script,[py,'report/'+script+'.py'])
print('Replay complete. The known Zoo static-integrity FAIL remains a FAIL; inspect replay-logs/commands.json.',flush=True)
