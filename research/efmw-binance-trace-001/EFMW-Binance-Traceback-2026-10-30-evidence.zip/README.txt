EFMW-BINANCE-TRACE-001 v0.1.0

Read report.html first. Full incident traceback: UNRESOLVED.

Reproduce the bounded checks offline with Python 3:
    python audit.py

audit_result.json is the machine-readable conclusion; trace_graph.json contains
only the inspected XRP payments and Ethereum token-event edges. No unobserved
connections, personal identities or intent claims are filled in.

The snapshots directory includes public chain API responses and the source
address feed. It does not include whole third-party news articles. Website
retrieval hashes and citations are recorded in source-manifest.json.

RPC captures include the exact original requests. Some discovery requests used
the latest validated ledger; the decisive XRP history and ledger cutoff are
fixed and preserved. Replaying discovery requests later changes their outputs.
rpc_capture.py accepts only read-only methods and can collect explicitly supplied
jobs. It is not an autonomous full-incident crawler.

method/ contains exact upstream snapshots and their licenses. CIRCUS is a report
gate, not an oracle of source truth. ELEPHANT preserves supplied event history.
MONSTER returned N/A eligibility, not a successful robustness test. No Lean build
was run. Provider consensus flags were inspected, not independently re-proven.

Inspect SHA256SUMS for the packaged evidence identities. No assets were moved.
