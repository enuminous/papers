#!/usr/bin/env python3
"""Reproduce bounded evidence checks. This is not a global blockchain crawler."""
import csv
from dataclasses import asdict
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
XRP_ACCOUNT = 'rK21t6nGLy4MNDqhvy3pGwcLFy25qgfzMx'
ETH_VICTIM = '0x28c6c06298d514db089934071355e5743bf21d60'
ETH_TX = '0x53bd38b816c23e74134786c29a8c18d792777998a3b9326047b583100e88e2f3'
TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
USDT = '0xdac17f958d2ee523a2206206994597c13d831ec7'

def read(name):
    return json.loads((ROOT / name).read_text())

def result(name):
    return read(name + '_capture.json')['response']['result']

def verify_blob(text, expected):
    data = text.encode()
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert actual == expected, ('source blob mismatch', actual, expected)

def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'method' / filename)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def main():
    checks = []
    # Verify evidence bytes against retrieval hashes before any interpretation.
    captures = sorted(ROOT.glob('*_capture.json'))
    verified_captures = 0
    unavailable = []
    for path in captures:
        capture = json.loads(path.read_text())
        if capture.get('sha256'):
            raw = ROOT / 'snapshots' / (capture['source_id'] + '.json')
            assert hashlib.sha256(raw.read_bytes()).hexdigest() == capture['sha256']
            verified_captures += 1
        if capture.get('error') or capture.get('response', {}).get('error'):
            unavailable.append({'source_id': capture['source_id'],
                'error': capture.get('error', capture.get('response', {}).get('error'))})
    checks.append({'check': 'RPC evidence byte hashes', 'result': 'PASS', 'count': verified_captures})

    snapshot = read('blocklist_snapshot.json')
    seed_raw = (ROOT / 'snapshots/elliptic_blocklist.csv').read_bytes()
    assert hashlib.sha256(seed_raw).hexdigest() == snapshot['sha256']
    rows = list(csv.reader(seed_raw.decode('utf-8-sig').splitlines()))
    assert all(len(r) == 1 and r[0].strip() for r in rows)
    addresses = [r[0].strip() for r in rows]
    assert len(addresses) == len(snapshot['rows']) == 1075
    assert snapshot['rows'][0]['address'] == addresses[0]
    def normalize(address):
        return address.lower() if re.fullmatch(r'0x[0-9a-fA-F]{40}', address) else address
    normalized = list(dict.fromkeys(map(normalize, addresses)))
    checks.append({'check': 'Headerless seed data, including first row', 'result': 'PASS', 'rows': len(rows)})
    checks.append({'check': 'Address strings after EVM case normalization', 'result': 'PASS', 'count': len(normalized),
        'limitation': 'Not a count of distinct chain-qualified accounts; chain IDs are absent.'})

    # XRP: use protocol integer drops, never explorer-formatted floating values.
    account = result('xrpl_account_info')
    history = result('xrp_fixed_history')
    cutoff = account['ledger_index']
    cutoff_header = result(f'xrp_ledger_{cutoff}')
    assert account['validated'] and history['validated'] and cutoff_header['validated']
    assert history['ledger_index_max'] == cutoff
    assert history['ledger_index_min'] <= 107986693 and 'marker' not in history
    assert cutoff_header['ledger_hash'] == account['ledger_hash']
    checks.append({'check': 'Pinned XRP history cutoff and no unconsumed pagination marker', 'result': 'PASS',
        'ledger_index': cutoff, 'ledger_hash': account['ledger_hash']})
    labelled = {t['hash']: t for t in read('xrpscan_transactions_capture.json')['response']['transactions']}
    transactions = history['transactions']
    assert len({t['tx']['hash'] for t in transactions}) == len(transactions)
    assert {t['tx']['hash'] for t in transactions} == set(labelled)
    checks.append({'check': 'XRPSCAN and public RPC transaction hash-set agreement', 'result': 'PASS', 'count': len(transactions)})
    xrp_edges, nonpayment, node_balance = [], [], 0
    source_total, incidental_total, outgoing, signed = 0, 0, 0, 0
    for item in transactions:
        tx, meta = item['tx'], item['meta']
        assert item['validated'] and meta['TransactionResult'] == 'tesSUCCESS'
        ledger = result(f"xrp_ledger_{tx['ledger_index']}")
        assert ledger['validated'] and tx['hash'] in ledger['ledger']['transactions']
        signed += int(tx['Account'] == XRP_ACCOUNT)
        if tx['TransactionType'] != 'Payment':
            nonpayment.append({'tx_hash': tx['hash'], 'type': tx['TransactionType'],
                              'effect': 'No XRP payment counted; not evidence of sender complicity.'})
        else:
            amount = meta.get('delivered_amount')
            assert isinstance(amount, str) and amount.isdecimal()
            amount = int(amount)
            source_label = labelled[tx['hash']].get('AccountName')
            source_associated = bool(source_label and source_label.get('name') == 'Binance')
            if tx['Destination'] == XRP_ACCOUNT:
                if source_associated:
                    source_total += amount
                else:
                    incidental_total += amount
            if tx['Account'] == XRP_ACCOUNT:
                outgoing += amount
            xrp_edges.append({'chain': 'xrpl-mainnet', 'asset': 'native:XRP',
                'tx_hash': tx['hash'], 'ledger_index': tx['ledger_index'], 'ledger_hash': ledger['ledger_hash'],
                'event_index': meta['TransactionIndex'], 'from': tx['Account'], 'to': tx['Destination'],
                'amount_atomic': str(amount), 'decimals': 6,
                'amount_display': str(Decimal(amount) / Decimal(10**6)),
                'time_utc': datetime.fromtimestamp(tx['date'] + 946684800, timezone.utc).isoformat(),
                'source_label': ('Binance ' + source_label.get('desc', '')) if source_associated else None,
                'label_evidence': 'XRPSCAN metadata; not a cryptographic ownership assertion',
                'scope': 'source-associated inflow' if source_associated else 'unattributed tiny inflow',
                'evidence_status': 'PUBLIC_LEDGER_CORROBORATED',
                'intent_inference': None})
        # Replay account-root balance changes independently of Payment sums.
        for change in meta.get('AffectedNodes', []):
            if 'CreatedNode' in change:
                node = change['CreatedNode']
                fields = node.get('NewFields', {})
                if node.get('LedgerEntryType') == 'AccountRoot' and fields.get('Account') == XRP_ACCOUNT:
                    assert node_balance == 0
                    node_balance = int(fields['Balance'])
            if 'ModifiedNode' in change:
                node = change['ModifiedNode']
                fields, previous = node.get('FinalFields', {}), node.get('PreviousFields', {})
                if node.get('LedgerEntryType') == 'AccountRoot' and fields.get('Account') == XRP_ACCOUNT:
                    if 'Balance' in previous:
                        assert int(previous['Balance']) == node_balance
                    if 'Balance' in fields:
                        node_balance = int(fields['Balance'])
    balance = int(account['account_data']['Balance'])
    assert node_balance == balance == source_total + incidental_total - outgoing
    assert outgoing == signed == 0
    assert source_total == 233461943100000 and incidental_total == 50
    assert len([e for e in xrp_edges if e['source_label']]) == 5
    checks.append({'check': 'XRP delivered amounts, account-state replay, and final balance agree exactly', 'result': 'PASS',
        'source_inflow_drops': str(source_total), 'incidental_inflow_drops': str(incidental_total),
        'closing_balance_drops': str(balance)})
    checks.append({'check': 'No account-signed transaction or outgoing payment through cutoff', 'result': 'PASS'})
    checks.append({'check': 'Nonpayment CheckCreate excluded from monetary flow', 'result': 'PASS', 'count': len(nonpayment)})

    # Ethereum: distinguish transaction caller from actual asset-transfer edges.
    chain, tx, receipt, block = result('eth_chain'), result('eth_tx'), result('eth_receipt'), result('eth_root_block')
    assert chain == tx['chainId'] == '0x1'
    assert receipt['status'] == '0x1' and receipt['transactionHash'] == tx['hash'] == ETH_TX
    assert receipt['blockHash'] == tx['blockHash'] == block['hash']
    assert receipt['blockNumber'] == tx['blockNumber'] == block['number']
    assert ETH_TX in block['transactions']
    assert tx['to'].lower() == ETH_VICTIM and int(tx['value'], 16) == 0
    eth_edges = []
    for log in receipt['logs']:
        topics = log.get('topics', [])
        if len(topics) != 3 or topics[0].lower() != TRANSFER_TOPIC:
            continue
        sender, receiver = '0x' + topics[1][-40:], '0x' + topics[2][-40:]
        if sender.lower() != ETH_VICTIM:
            continue
        assert not log.get('removed', False)
        assert log['transactionHash'] == ETH_TX and log['blockHash'] == block['hash']
        assert len(log['data']) == 66
        eth_edges.append({'chain': 'eip155:1', 'asset': log['address'].lower(),
            'tx_hash': ETH_TX, 'block_number': int(block['number'], 16), 'block_hash': block['hash'],
            'event_index': int(log['logIndex'], 16), 'from': sender.lower(), 'to': receiver.lower(),
            'amount_atomic': str(int(log['data'], 16)),
            'evidence_status': 'PUBLIC_RPC_RECEIPT_EVENT',
            'limitation': 'Event emission verified from provider data; no independent token-code or balance-state replay.'})
    assert len(eth_edges) == 63 and len({e['event_index'] for e in eth_edges}) == 63
    assert len({e['asset'] for e in eth_edges}) == 63
    recipients = {e['to'] for e in eth_edges}
    assert recipients == {'0x5227f603c1ee34ce3c06efe6477003bdfccb2f8c'}
    usdt = [e for e in eth_edges if e['asset'] == USDT]
    assert len(usdt) == 1 and usdt[0]['amount_atomic'] == '1615409498973240'
    metadata = read('asset_metadata.json')
    assert metadata['chain'] == 'eip155:1' and metadata['contract'] == USDT and metadata['decimals'] == 6
    usdt_display = format((Decimal(usdt[0]['amount_atomic']) / Decimal(10**metadata['decimals'])).quantize(Decimal('0.000001')), 'f')
    checks.append({'check': 'Ethereum chain, transaction, receipt and block inclusion agree', 'result': 'PASS'})
    checks.append({'check': '63 distinct victim-origin Transfer events; USDT atomic amount fixed', 'result': 'PASS'})

    pins = read('method/source-pins.json')
    for entry in pins['extensions']:
        verify_blob(entry['content'], entry['git_blob_sha1'])
        assert (ROOT / 'method' / Path(entry['path']).name).read_text() == entry['content']
    elephant_pin = next(f for f in pins['elephant']['files'] if f['path'] == 'elephant.py')
    verify_blob(elephant_pin['content'], elephant_pin['git_blob_sha1'])
    assert (ROOT / 'method/elephant_elephant.py').read_text() == elephant_pin['content']
    checks.append({'check': 'Canonical Zoo source blob identities', 'result': 'PASS'})

    elephant = module('trace_elephant', 'elephant_elephant.py')
    memory = elephant.ElephantMemory()
    event_inputs = [
        {'id': 'seed-parse-initial', 'time': 1, 'actor': 'audit parser', 'content': 'Exploratory header parsing omitted the first row.',
         'provenance': snapshot['sha256'], 'confidence': 0.0},
        {'id': 'seed-parse-corrected', 'time': 2, 'actor': 'audit parser', 'content': 'Headerless CSV contains 1075 records.',
         'provenance': snapshot['sha256'], 'supersedes': 'seed-parse-initial', 'confidence': 1.0},
        {'id': 'xrp-cutoff', 'time': 3, 'actor': 'public RPC', 'content': 'Five source-associated inflows reconcile to XRP account balance plus dust.',
         'provenance': account['ledger_hash'], 'confidence': 1.0},
        {'id': 'eth-receipt', 'time': 4, 'actor': 'public RPC', 'content': 'Pinned successful receipt contains 63 victim-origin Transfer logs.',
         'provenance': block['hash'], 'confidence': 1.0},
    ]
    for event in event_inputs:
        memory.add_event(elephant.Event(**event))
    lineage = [e.id for e in memory.lineage('seed-parse-corrected')]
    assert lineage == ['seed-parse-corrected', 'seed-parse-initial']
    assert 'seed-parse-initial' not in [e.id for e in memory.current_events()]
    elephant_result = {'operation': 'ELEPHANT history/current/lineage', 'scope': 'Supplied audit records only',
        'result': 'PASS', 'source_truth_verified_by_operator': False,
        'lineage': lineage, 'history': [asdict(e) for e in memory.history()],
        'active': [e.id for e in memory.current_events()],
        'confidence_note': 'Input bookkeeping values are not calibrated probabilities.'}
    write('elephant_inputs.json', event_inputs)
    write('elephant_result.json', elephant_result)

    circus_input = {
        'animal': 'CIRCUS', 'decision': 'FAIL',
        'claim': 'The entire Binance theft has a complete independently reproducible end-to-end traceback.',
        'pipeline': [{'stage': 'definition', 'provenance_status': 'documented'},
                     {'stage': 'data_selection', 'provenance_status': 'incomplete'},
                     {'stage': 'labels', 'provenance_status': 'source-attributed'},
                     {'stage': 'validation', 'provenance_status': 'partial'}],
        'dependencies': [{'name': 'Complete root set and per-chain ledger exports', 'materiality': 'material', 'feedback': False}],
        'risks': [{'name': 'Unmatched roots, cross-chain transitions and custody endpoints', 'materiality': 'material', 'status': 'unresolved'},
                  {'name': 'No actor-specific evidence of knowledge or state direction', 'materiality': 'material', 'status': 'unresolved'}],
        'independent_checks': [{'name': 'Bounded XRP reconciliation', 'status': 'passed', 'frozen': True, 'independently_sourced': True},
                               {'name': 'All-chain completeness', 'status': 'unresolved', 'frozen': False, 'independently_sourced': False}]
    }
    circus = module('trace_circus', 'circus.py')
    gate = circus.decide(circus_input)
    assert gate == 'FAIL'
    write('circus_input.json', circus_input)
    write('circus_result.json', {'gate': gate, 'meaning': 'Rejects the claim of complete traceback; does not reject the occurrence of the theft.',
                                 'epistemic_status': 'UNRESOLVED'})
    monster_input = {'animal': 'MONSTER', 'decision': 'N/A',
        'preregistration': {'registered_before_outcomes': False, 'protocol_id': None},
        'metric': {'direction': 'higher_is_better', 'tolerance': None},
        'baseline': {'matched': False}, 'conditions': [], 'failure_boundaries': []}
    monster = module('trace_monster', 'monster.py')
    eligibility = monster.decide(monster_input)
    assert eligibility == 'N/A'
    write('monster_input.json', monster_input)
    write('monster_result.json', {'eligibility': eligibility, 'meaning': 'No preregistered comparative performance experiment; no robustness or superiority claim.'})
    checks.append({'check': 'Full-trace assertion rejected by unmodified CIRCUS gate', 'result': 'PASS', 'gate_output': gate})

    summary = {
        'audit_id': 'EFMW-BINANCE-TRACE-001', 'version': '0.1.0',
        'full_trace_status': 'UNRESOLVED', 'complete_trace_acceptance_gate': gate,
        'seed_rows': len(rows), 'normalized_address_strings': len(normalized),
        'chain_assignment_complete': False,
        'xrp': {'account': XRP_ACCOUNT, 'cutoff_ledger': cutoff, 'cutoff_hash': account['ledger_hash'],
                'cutoff_time_utc': cutoff_header['ledger']['close_time_iso'],
                'source_associated_inflows': 5, 'source_inflow_drops': str(source_total),
                'source_inflow_xrp': str(Decimal(source_total) / Decimal(10**6)),
                'incidental_inflow_drops': str(incidental_total),
                'closing_balance_drops': str(balance),
                'closing_balance_xrp': str(Decimal(balance) / Decimal(10**6)),
                'outgoing_payment_count': 0, 'account_signed_transaction_count': 0,
                'transactions_in_history': len(transactions), 'nonpayment_count': len(nonpayment),
                'scope': 'Complete returned account history through cutoff, not the complete incident.'},
        'ethereum': {'transaction': ETH_TX, 'block_number': int(block['number'],16), 'block_hash': block['hash'],
                     'caller': tx['from'], 'recipient_contract_context': tx['to'],
                     'transfer_events_from_victim': 63, 'transfer_recipient': next(iter(recipients)),
                     'usdt_atomic_amount': usdt[0]['amount_atomic'],
                     'usdt_display_explorer': usdt_display,
                     'native_eth_explorer_only': '167464.247856558836135296',
                     'internal_trace_rpc_verified': False,
                     'scope': 'One root transaction; token logs corroborated, later movement not exhaustively traced.'},
        'identity': {'individual_hackers': 'UNRESOLVED', 'knowing_launderers_this_incident': 'UNRESOLVED',
                     'dprk': 'SOURCE_SUPPORTED_NOT_INDEPENDENTLY_PROVEN'},
        'unavailable_rpc': unavailable,
        'operations': {'ELEPHANT': 'PASS on supplied evidence bookkeeping', 'CIRCUS': 'FAIL on complete-trace claim',
                       'MONSTER': 'N/A eligibility only', 'OTHER_ANIMALS': 'NOT RUN; no suitable frozen feature inputs'},
        'checks': checks,
        'limits': ['No local full-node validation or independent cryptographic inclusion-proof verification.',
                   'Provider labels are not legal identity or evidence of knowledge.',
                   'No complete 11-chain theft-root set, global denominator or full cross-chain graph.',
                   'No private exchange records, bank records, signer logs, or access to law-enforcement evidence.']
    }
    write('trace_graph.json', {'schema_version': '1.0', 'xrp_edges': xrp_edges, 'ethereum_log_edges': eth_edges,
                             'nonmonetary_xrp_events': nonpayment, 'complete_incident_graph': False})
    write('audit_result.json', summary)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
