#!/usr/bin/env python3
"""Read-only public-source capture for a bounded EFMW evidence audit."""
import concurrent.futures
import datetime
import hashlib
import json
from html.parser import HTMLParser
from pathlib import Path
import re
import urllib.request

ROOT = Path(__file__).resolve().parent

class Extract(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts, self.links, self.skip = [], [], 0
    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.skip += 1
        if tag == 'a':
            href = dict(attrs).get('href')
            if href:
                self.links.append(href)
    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.skip = max(0, self.skip - 1)
    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip())

def capture(item):
    source_id, url = item
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record = {'source_id': source_id, 'requested_url': url, 'retrieved_utc': stamp}
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (public evidence audit)'})
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read(5_000_001)
            if len(raw) > 5_000_000:
                raise ValueError('Response exceeded capture limit; no partial source accepted')
            record.update(final_url=response.url, status=response.status,
                          content_type=response.headers.get('Content-Type'))
        record['sha256'] = hashlib.sha256(raw).hexdigest()
        record['bytes'] = len(raw)
        folder = ROOT / 'snapshots'
        folder.mkdir(exist_ok=True)
        (folder / (source_id + '.html')).write_bytes(raw)
        parser = Extract()
        parser.feed(raw.decode('utf-8', errors='replace'))
        text = '\n'.join(parser.parts)
        (folder / (source_id + '.txt')).write_text(text)
        record['links'] = sorted(set(parser.links))
        record['address_candidates'] = sorted(set(re.findall(r'\b0x[0-9a-fA-F]{40}\b', text)))
        record['transaction_hash_candidates'] = sorted(set(re.findall(r'\b0x[0-9a-fA-F]{64}\b', text)))
        record['capture_status'] = 'captured'
        excerpts = [part for part in parser.parts if re.search(
            r'Binance|October|freeze|frozen|blocklist|blacklist|wallet|launder|Korea|billion|million|Ethereum|TRM|Elliptic|Chainalysis', part, re.I)]
        record['inspection_text'] = '\n'.join(excerpts)[:25000]
    except Exception as error:
        record.update(capture_status='failed', error=f'{type(error).__name__}: {error}')
    return record

if __name__ == '__main__':
    import sys
    jobs = json.loads(sys.stdin.read())
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        results = list(executor.map(capture, jobs))
    manifest = ROOT / 'capture_manifest.json'
    prior = json.loads(manifest.read_text()) if manifest.exists() else []
    ids = {r['source_id'] for r in results}
    combined = [r for r in prior if r['source_id'] not in ids] + results
    manifest.write_text(json.dumps(combined, indent=2))
    for result in results:
        print(json.dumps({key: result.get(key) for key in (
            'source_id', 'requested_url', 'retrieved_utc', 'status',
            'sha256', 'bytes', 'capture_status', 'error')}))
