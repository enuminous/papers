#!/usr/bin/env python3
"""Capture public, read-only RPC evidence from a JSON job list on stdin."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
ALLOWED_METHODS = {
    'account_info', 'account_tx', 'ledger', 'tx',
    'eth_chainId', 'eth_getTransactionByHash', 'eth_getTransactionReceipt',
    'eth_getBlockByHash', 'eth_getBlockByNumber', 'eth_call', 'eth_getCode',
    'trace_transaction', 'debug_traceTransaction', 'web3_sha3',
}

def capture(job):
    name, url, body = job['name'], job['url'], job['body']
    if not name.replace('_', '').isalnum():
        raise ValueError('Unsafe capture name')
    if body.get('method') not in ALLOWED_METHODS:
        raise ValueError('Only read-only methods are permitted')
    record = {'source_id': name, 'url': url, 'request': body,
              'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        request = urllib.request.Request(url, data=json.dumps(body).encode(),
            headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0 (public evidence audit)'})
        with urllib.request.urlopen(request, timeout=25) as response:
            raw = response.read(5_000_001)
            if len(raw) > 5_000_000:
                raise ValueError('Evidence exceeds size bound; partial data rejected')
        (ROOT / 'snapshots').mkdir(exist_ok=True)
        (ROOT / 'snapshots' / f'{name}.json').write_bytes(raw)
        record.update(sha256=hashlib.sha256(raw).hexdigest(), response=json.loads(raw))
        record['capture_status'] = 'captured'
    except Exception as error:
        record.update(capture_status='failed', error=f'{type(error).__name__}: {error}')
    (ROOT / f'{name}_capture.json').write_text(json.dumps(record, indent=2))
    result = record.get('response', {}).get('result')
    return {'name': name, 'capture_status': record['capture_status'],
            'error': record.get('error', record.get('response', {}).get('error')),
            'result_type': type(result).__name__,
            'result_count': len(result) if isinstance(result, (list, dict)) else None,
            'scalar': result if isinstance(result, (str, int)) else None}

if __name__ == '__main__':
    jobs = json.load(sys.stdin)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for result in executor.map(capture, jobs):
            print(json.dumps(result))
