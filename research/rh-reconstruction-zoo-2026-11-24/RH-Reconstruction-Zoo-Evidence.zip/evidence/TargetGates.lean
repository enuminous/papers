import Turtle
import Weasel
import Salmon
import Extensions
open Zoo

def scopeVeto : Turtle.Input := ⟨true, true, 0, 0, 0, 0.0, 3, 0.18, 0.05⟩
#guard Turtle.run scopeVeto == .notSupported
#guard Turtle.run {scopeVeto with anyApplicable := false} == .insufficient

def boundaryRows : List Weasel.Finding := [⟨4, 4.0, 4.0, 1.0⟩, ⟨1, 1.0, 1.0, 1.0⟩, ⟨4, 4.0, 4.0, 1.0⟩, ⟨2, 2.0, 2.0, 1.0⟩, ⟨2, 2.0, 2.0, 1.0⟩, ⟨3, 3.0, 3.0, 1.0⟩, ⟨2, 2.0, 2.0, 1.0⟩]
#guard (Weasel.retain 2 boundaryRows).length == 4
#guard (Weasel.retain 0 boundaryRows).isEmpty

-- IDs: 0 riemannHypothesis; 1 rhOfAll; 2 rh_of_every; 3 allChi; 4 everyCharacter.
-- The bounded test stops before any uninspected parent list is consulted.
def parents : Nat → List Nat
  | 0 => [1]
  | 1 => [2,3]
  | 3 => [4]
  | _ => []
def boundedFrontier : Bool := match Salmon.trace parents 2 0 with
  | .branch 0 [.branch 1 [.exhausted 2, .exhausted 3]] => true
  | _ => false
#guard boundedFrontier

def graphGate : Extensions.Circus.Summary := ⟨true, false, false, false, true, true, true, true⟩
#guard Extensions.Circus.decideGate graphGate == .fail
#guard Extensions.Circus.decideGate {graphGate with riskOpen := false, checkFailed := false} == .na
#guard Extensions.Circus.decideGate ⟨false,false,false,false,false,false,false,true⟩ == .pass
