# Replaying the RH reconstruction audit

Start with **RH-Reconstruction-Zoo-Audit.md**. The target and all review inputs are public. The audit package contains the source checks, controls, generated target Lean test, native logs, result tables and their SHA-256 receipts. It omits the large original proof and system toolchains. The CSV roster includes all 53 named dispositions.

Use Python 3.11 or newer, Git, curl and standard Poppler utilities. The document raster comparison uses NumPy and PyMuPDF 1.26.6. Graph regeneration also imports NumPy. Use a fresh checkout for each reference suite. Run the following shell commands from the extracted audit folder. The inventory's historical lookup needs complete Git history. The document replay needs a TeX Live environment with the packages in the target preambles and the recorded font packages.

```sh
sha256sum -c SHA256SUMS
git clone https://github.com/jimjamzola/RH-Alpoge-Reconstruction target
git -C target checkout --detach aa9c86bf2a7d29b08575641fecea19a2a603e87c
git clone https://github.com/enuminous/Monolithic-Zoo-Lean4 zoo
git -C zoo checkout --detach b12200364f7d1424c4d9cdfbe20fff4d52de379d
python3 scripts/inventory.py target
python3 scripts/get_archive.py download
python3 scripts/archive_scan.py download/lean.tar.gz
python3 scripts/ledger.py target
python3 scripts/source_locations.py target download/lean.tar.gz
python3 scripts/boundary.py target
python3 scripts/transfer_control.py
python3 scripts/documents.py target
python3 -B target/audit/final_certification/scripts/gc_live.py >evidence/graph-replay.log 2>&1
echo "exit $?" >>evidence/graph-replay.log
```

The unmodified graph command is expected to report a missing upstream index in a clean checkout. Put the Lean 4.19.0 binaries on PATH for the following operations. The audit of the formal source archive uses its own recorded Lean 4.33.1 pin. The published native controls and the RH-specific tests check different things.

```sh
python3 scripts/native_zoo.py zoo
python3 scripts/target_gates.py target zoo
git clone https://github.com/enuminous/Pegasus pegasus
git -C pegasus checkout --detach 41d57615f16c43ea8858e35cd1250d44c3c7df97
(cd pegasus && python3 -B -m unittest discover -s tests -v)
```

The scripts write into evidence/. Verify the delivered checksums before replay or run on a copy. Build logs can vary by path, clock, tooling and font versions. A repeat of the RH kernel build requires a larger environment and the recorded upstream procedure in target/docs/SOURCE_MANIFEST.md. The graph output and its pre-indexes are a different computation.

## How to read the evidence

| File | What it establishes |
| --- | --- |
| protocol/criteria.md and protocol/roster.json | Frozen retrospective review criteria, roster and source revisions |
| claim-ledger.csv and Zoo-roster.csv | Per-claim and per-operation findings and evidence |
| evidence/git-files.sha256 and inventory.json | Exact target inventory and historical document receipts |
| evidence/archive-scan.json and archive-* source/config files | Whole-archive hash, import closure, token scan, pins and headline statement headers |
| evidence/external-kernel-receipt.json | Third-party kernel log identification and five axiom checks |
| evidence/ledger.json and source-locations.json | Independent whole-ledger recount and cross-check against Lean source lines |
| evidence/boundary-diff.json | Row-by-row negative finding, paired source fields, drift and TSV coordinates |
| evidence/document-build.json and tex-* logs | Shipped and rebuilt PDFs, diagnostics and text comparisons |
| evidence/native-zoo.log, pegasus-fixtures.log and target-gates.json | Native baseline/controls and four actual target evaluations |
| evidence/transfer-controls.json | Small-prime sanity and rejection controls |
| evidence/graph-replay.log | Exact failure of the published declaration-graph entry point |

A name match on a source line is a location test. The suffix check does not establish Lean name resolution or a dependency edge. The token scan is a literal whole-word source check. Neither substitutes for kernel elaboration. The gate adapter is intentionally bound to this audited revision.
