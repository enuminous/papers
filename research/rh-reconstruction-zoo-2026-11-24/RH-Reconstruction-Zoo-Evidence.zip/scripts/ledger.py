"""Recount the producer's output without using the producer's graph code."""
import csv, gzip, hashlib, json, sys
from collections import Counter
from pathlib import Path
ev=Path(__file__).resolve().parents[1]/'evidence'; root=Path(sys.argv[1])/'audit/final_certification'
def tsv(path):
 with path.open() as f:return list(csv.DictReader(f,delimiter='\t'))
s=json.loads((root/'dag_stats.json').read_text()); owners=Counter(); groups=Counter(); kinds=Counter(); names=set(); identities=set(); repeated=[]; missing=Counter();sample=None
with gzip.open(root/'Global_Ownership.tsv.gz','rt') as f:
 for r in csv.DictReader(f,delimiter='\t'):
  name=r['declaration']; loc=r['file:line']; key=(name,loc); names.add(name)
  if key in identities and len(repeated)<10:repeated.append(key)
  identities.add(key); live=r['liveness']; status=r['status']; group=(live,status); groups[group]+=1
  missing.update(k for k,v in r.items() if not v)
  if live!='LIVE (exact edges)':continue
  if sample is None:sample=group
  kinds[r['kind']]+=1
  o=r['owner_or_evidence']
  if o.startswith('region of '):o='region: '+o[len('region of '):].split(' [')[0]
  elif o.startswith('shared Lean-internal'):o='shared Lean-internal remainder'
  elif o.startswith('definition, no proof obligation'):o='definitions in package regions'
  owners[(status,o[:110])]+=1
published=tsv(root/'Global_Published_Statements.tsv'); boundary=tsv(root/'Global_External_Boundary.tsv'); recon=tsv(root/'Global_Residual_Reconciliation.tsv')
expected_owners={(r['status'],r['owner']):int(r['declarations']) for r in tsv(root/'owner_summary.tsv')}
def gate(g):
 observed={v:n for (lv,v),n in g.items() if lv=='LIVE (exact edges)' and n}
 return sum(g.values())==s['live_dot'] and observed==s['status'] and sum(observed.values())==s['live']
controls={}
for label,delta in [('removed',-1),('duplicated',1),('relabelled',-1)]:
 trial=groups.copy();trial[sample]+=delta
 if label=='relabelled':trial[(sample[0],'EXTERNAL' if sample[1]!='EXTERNAL' else 'CLOSED')]+=1
 controls[label]=not gate(trial)
assert gate(groups) and all(controls.values())
report=dict(rows=sum(groups.values()),distinct_names=len(names),distinct_name_locations=len(identities),duplicate_name_location_examples=repeated,missing_fields=dict(missing),by_group={lv:{st:n for (l,st),n in groups.items() if l==lv} for lv,st in groups},exact_kinds=kinds,kinds_match=kinds==s['kinds'],owner_rows=len(owners),all_owner_counts_match=owners==expected_owners,producer_status_totals_match=gate(groups),negative_controls_rejected=controls,published_statements=len(published),published_named_proofs=sum(bool(r['proved_in_archive_by'].strip()) for r in published),published_status_key_overlap=sum((r['declaration'],r['file:line']) in identities for r in published),external_rows=len(boundary),external_match_labels=Counter(r['match_or_fidelity'] for r in boundary),reconciliation_rows=len(recon),secondhand_ids=[r['item'] for r in recon if 'not in workspace' in ' '.join(r.values()).lower()],residual_data_rows=len([s for s in (root/'Global_Residuals.tsv').read_text().splitlines()[1:] if s.strip() and not s.startswith('#')]))
(ev/'ledger.json').write_text(json.dumps(report,indent=2))
