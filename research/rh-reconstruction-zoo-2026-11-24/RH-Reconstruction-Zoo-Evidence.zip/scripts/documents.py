"""Compile the two manuscripts in clean temporary directories and compare extracted text."""
import sys, shutil, tempfile, subprocess, json, re, hashlib
from pathlib import Path
target=Path(sys.argv[1]).resolve()
ev=Path(__file__).resolve().parents[1]/'evidence'
def run(args,cwd):
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 return p.returncode,p.stdout
def extract(path):
 return run(['pdftotext','-enc','UTF-8',str(path),'-'],path.parent)[1]
def raster(first,second):
 import pymupdf
 import numpy as np
 perpage=[]
 with pymupdf.open(first) as a,pymupdf.open(second) as b:
  for no,(pa,pb) in enumerate(zip(a,b),1):
   left=pa.get_pixmap(dpi=96,colorspace=pymupdf.csGRAY,alpha=False)
   right=pb.get_pixmap(dpi=96,colorspace=pymupdf.csGRAY,alpha=False)
   if (left.width,left.height)!=(right.width,right.height):perpage.append({'page':no,'dimensions_changed':True});continue
   x=np.frombuffer(left.samples,dtype=np.uint8);y=np.frombuffer(right.samples,dtype=np.uint8)
   diff=int((x!=y).sum())
   if diff:perpage.append(dict(page=no,changed_pixels=diff,pixels=int(x.size)))
  return dict(dpi=96,channels='grayscale',renderer=pymupdf.VersionBind,total_shipped=len(a),total_rebuilt=len(b),differing_pages=len(perpage),details=perpage)
def compare(first,second):
 import difflib
 a=extract(first).decode().split('\f'); b=extract(second).decode().split('\f')
 ws=lambda line: ''.join(line.split())
 pages=[i for i,(x,y) in enumerate(zip(a,b),1) if x!=y]
 norm=[i for i,(x,y) in enumerate(zip(a,b),1) if ws(x)!=ws(y)]
 diffs=[]
 for i in norm[:3]:
  left=a[i-1].split();right=b[i-1].split()
  for tag,j,k,l,m in difflib.SequenceMatcher(None,left,right,autojunk=False).get_opcodes():
   if tag!='equal':
    diffs.append(dict(page=i,tag=tag,shipped=' '.join(left[j:k])[:60],rebuilt=' '.join(right[l:m])[:60]));break
 return dict(raw_different_pages=pages,whitespace_stripped_different_pages=norm,equal_pages_length=len(a)==len(b),sample_differences=diffs)
def details(path):
 info=run(['pdfinfo',str(path)],path.parent)[1].decode()
 txt=run(['pdftotext','-enc','UTF-8',str(path),'-'],path.parent)[1]
 return {'pages':int(re.search(r'Pages:\s*(\d+)',info)[1]),'text_sha256':hashlib.sha256(txt).hexdigest(),'text_question_pairs':txt.count(b'??')}
result={}
for name,loc,stem,bib in [('current','manuscript','main',True),('early','archive/route-notes','RH_Route_Notes',False)]:
 with tempfile.TemporaryDirectory() as td:
  folder=Path(td)/'source'
  shutil.copytree(target/loc,folder,ignore=shutil.ignore_patterns('*.aux','*.out','*.bbl','*.blg','*.log','*.toc',stem+'.pdf'))
  row={'shipped':details(target/loc/(stem+'.pdf')),'steps':[]}; result[name]=row
  tex=['pdflatex','-no-shell-escape','-halt-on-error','-interaction=nonstopmode',stem+'.tex']
  for n,args in enumerate([tex]+([['bibtex',stem]] if bib else [])+[tex,tex]):
   rc,out=run(args,folder); (ev/f'tex-{name}-{n}.log').write_bytes(out)
   row['steps'].append({'argv':args,'exit':rc})
   if rc: break
  if not rc:
   row['rebuilt']=details(folder/(stem+'.pdf'))
   row['text_comparison']=compare(target/loc/(stem+'.pdf'),folder/(stem+'.pdf'))
   row['raster_comparison']=raster(target/loc/(stem+'.pdf'),folder/(stem+'.pdf'))
   row['issues']=[s for s in (folder/(stem+'.log')).read_text(errors='replace').splitlines() if re.search('undefined|multiply defined|Rerun to get|multiply-defined',s,re.I)]
(ev/'document-build.json').write_text(json.dumps(result,indent=2))
