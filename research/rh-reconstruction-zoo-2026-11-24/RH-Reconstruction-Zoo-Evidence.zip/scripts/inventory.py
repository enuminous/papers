"""Check all document receipts, since a historical path may have moved."""
import csv, subprocess, re, json, hashlib, sys
from pathlib import Path
root=Path(sys.argv[1]).resolve(); ev=Path(__file__).resolve().parents[1]/'evidence'
def git(*args):
 return subprocess.check_output(['git',*args],cwd=root)
paths=git('ls-files','-z').decode().rstrip('\0').split('\0')
def h(b):return hashlib.sha256(b).hexdigest()
current={p:h((root/p).read_bytes()) for p in paths}
(ev/'git-files.sha256').write_text(''.join(f'{v}  {p}\n' for p,v in current.items()))
man=(root/'docs/SOURCE_MANIFEST.md').read_text(); rows=[]
for name,expected in re.findall(r'^\| `([^`]+)` \| [^\n]+?\| `([a-f0-9]{64})` \|$',man,re.M):
 track=[p for p in paths if p==name or p.endswith('/'+name)]
 if len(track)!=1:raise ValueError((name,track))
 p=track[0]; row=dict(manifest_path=name,current_path=p,expected=expected,actual=current[p],present_as_named=name==p,bytes_match=current[p]==expected)
 if not row['bytes_match']:
  for oldpath in dict.fromkeys([p,name]):
   for rev in git('log','--diff-filter=AM','--format=%H','--',oldpath).decode().splitlines():
    if h(git('show',f'{rev}:{oldpath}'))==expected:
     row.update(historical_commit_with_matching_bytes=rev,historical_path=oldpath);break
   if 'historical_commit_with_matching_bytes' in row:break
 rows.append(row)
(ev/'inventory.json').write_text(json.dumps(dict(pin=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),files=len(paths),tracked_lean=[p for p in paths if p.endswith('.lean')],receipts=rows),indent=2))
