"""Fetch the author's numbered parts and authenticate joined bytes. Supply a working folder."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib, subprocess, sys, shutil
w=Path(sys.argv[1]); w.mkdir(parents=True,exist_ok=True)
expected='9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc'
def get(i):
 f=w/('lean.tar.gz.part%02d'%i)
 subprocess.run(['curl','-fsSL','--retry','2','--max-time','70','https://alpo.ge/'+f.name,'-o',str(f)],check=True)
 return f
with ThreadPoolExecutor(7) as pool:
 parts=list(pool.map(get,range(1,15)))
out=w/'lean.tar.gz'
with out.open('wb') as dest:
 for p in parts:
  with p.open('rb') as src: shutil.copyfileobj(src,dest)
with out.open('rb') as src: got=hashlib.file_digest(src,'sha256').hexdigest()
print(out.name,out.stat().st_size,got,flush=True)
if got!=expected: raise ValueError('Archive digest mismatch')
