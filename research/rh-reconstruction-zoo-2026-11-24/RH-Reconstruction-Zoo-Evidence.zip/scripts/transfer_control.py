"""Cyclic p^2 transfer model with subgroup order p and index p. All arithmetic is exact."""
from pathlib import Path
import json
rows=[]
for p in (2,3,5,7):
 n=p*p
 def transfer(x):return x%p
 def inclusion(y):return p*y%n
 results=dict(prime=p,group_order=n,index=p,subgroup_torsion_order=p,
     projection_after_transfer_equals_index=all(inclusion(transfer(x))==p*x%n for x in range(n)),
     product_annihilates=all(p*p*x%n==0 for x in range(n)),
     dropping_index_fails_at_one=(p*1)%n!=0)
 assert all(v for k,v in results.items() if isinstance(v,bool))
 rows.append(results)
(Path(__file__).resolve().parents[1]/'evidence/transfer-controls.json').write_text(json.dumps(rows,indent=2))
