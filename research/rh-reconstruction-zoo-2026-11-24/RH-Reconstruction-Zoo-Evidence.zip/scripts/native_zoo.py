"""Run from the evidence package: python3 scripts/native_zoo.py PATH_TO_ZOO, with pinned Lean on PATH."""
import sys, subprocess, pathlib, datetime, shutil
zoo=pathlib.Path(sys.argv[1]).resolve()
evidence=pathlib.Path(__file__).resolve().parents[1]/'evidence'
commands=['python3 verify.py','lake build','lake env lean -DwarningAsError=true Audit.lean','python3 scripts/test_axiom_audit.py','python3 scripts/extension_fixtures.py','python3 scripts/report_fixtures.py','lake env lean -DwarningAsError=true .lake/SourceReportFixtures.lean','python3 scripts/threshold_fixtures.py','lake env lean -DwarningAsError=true .lake/ThresholdFixtures.lean','python3 scripts/test_alternative_report.py','lake exe regression','lake exe zoo46']
with (evidence/'native-zoo.log').open('w') as out:
 for cmd in commands:
  print('$ '+cmd,file=out,flush=True)
  run=subprocess.run(cmd.split(),cwd=zoo,stdout=out,stderr=subprocess.STDOUT)
  print('EXIT',run.returncode,file=out,flush=True)
