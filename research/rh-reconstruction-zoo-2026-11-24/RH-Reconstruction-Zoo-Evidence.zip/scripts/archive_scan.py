"""Authenticate and scan the archive. Store no executable object from the archive."""
import tarfile, re, sys, hashlib, json, collections
from pathlib import Path
ev=Path(__file__).resolve().parents[1]/'evidence'
archive=Path(sys.argv[1])
with archive.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
assert digest=='9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc'
tokens=re.compile(rb'\b(axiom|sorry|admit|unsafe|native_decide|implemented_by|extern|opaque|ofReduceBool|trustCompiler|skipKernelTC|addDecl|kcopy|kexactB)\b')
imports=re.compile(rb'^\s*(?:(?:public|private|meta)\s+)*import\s+([^\n]+)',re.M)
tally=collections.Counter(); mentions=collections.Counter(); meta=set(); modules={}; files={}; size=lines=0; stems=[]; raw_meta=set(); meta_only=[]; excerpts=[]
with tarfile.open(archive,'r|gz') as t:
 for item in t:
  if not item.isfile():continue
  name=item.name.removeprefix('./'); b=t.extractfile(item).read()
  if name in files:raise ValueError('duplicate '+name)
  files[name]=hashlib.sha256(b).hexdigest()
  if name.split('/')[-1] in ('Main.lean','Statements.lean','lake-manifest.json','lakefile.toml','lean-toolchain') and (name.count('/')<3):
   (ev/('archive-'+name.rsplit('/',1)[-1])).write_bytes(b)
  if not name.endswith('.lean'):continue
  assert name.startswith('lean/src/'), name
  key=name[9:-5].replace('/','.')
  dep=[]
  for row in imports.findall(b):
   toks=row.split(b'--')[0].decode().split()
   dep.extend(toks)
  modules[key]=dep
  size+=len(b); lines+=b.count(b'\n')
  c=collections.Counter(v.decode() for v in tokens.findall(b));tally.update(c);mentions.update(c.keys())
  if set(c)&{'kcopy','kexactB','addDecl'}:meta.add(key)
  if any(term in b for term in (b'kcopy',b'kexactB',b'addDecl')):
   raw_meta.add(key)
   if not set(c)&{'kcopy','kexactB','addDecl'}:meta_only.append(key)
  if b'b2PowA' in b or b'secondCohomologyBound_of_boundaryBound' in b:stems.append(key)
  if name.endswith('/Kernels/MainTheorems.lean'):
   excerpts=[v for v in b.decode().splitlines() if any(w in v for w in ('rhOfAll','allChi','rh_of_every','everyCharacter'))][:30]
seen=set();todo=['Main']
while todo:
 m=todo.pop()
 if m in seen:continue
 seen.add(m);todo.extend(v for v in modules[m] if v in modules and v not in seen)
variants={}
for prefix,strip in [('lean/',5),('./',5),('',5),('original',0)]:
 def key(n):
  if prefix=='original':return n
  return ('' if prefix=='lean/' else prefix)+n[strip:] if prefix!='lean/' else 'lean/'+n[strip:]
 h=hashlib.sha256()
 for n in sorted(files,key=lambda k:key(k).encode()):h.update((files[n]+'  '+key(n)+'\n').encode())
 variants[prefix]=h.hexdigest()
(ev/'archive-scan.json').write_text(json.dumps(dict(archive_sha256=digest,regular_files=len(files),lean_files=len(modules),lean_bytes=size,newlines=lines,local_import_closure=len(seen),unreached=sorted(modules.keys()-seen)[:30],other_paths=[v for v in files if not v.endswith('.lean')],token_occurrences=dict(tally),files_with_token=dict(mentions),metaprogramming_union=len(meta),hashlist_variants=variants,cohomology_modules_containing_anchor=stems[:50],substring_files=len(raw_meta),substring_only=meta_only,root_excerpt=excerpts),indent=2))
