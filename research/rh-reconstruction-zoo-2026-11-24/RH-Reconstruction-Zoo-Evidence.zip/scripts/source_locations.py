"""Check every ledger coordinate against authenticated, original Lean source bytes."""
import csv,gzip,tarfile,json,sys,re,hashlib
from collections import defaultdict,Counter
from pathlib import Path
target=Path(sys.argv[1]);arc=Path(sys.argv[2]);ev=Path(__file__).resolve().parents[1]/'evidence'
with arc.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()=='9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc'
refs=defaultdict(list);tally=Counter();issues=[]; anchors=[]
with gzip.open(target/'audit/final_certification/Global_Ownership.tsv.gz','rt') as f:
 for row in csv.DictReader(f,delimiter='\t'):
  path,pos=row['file:line'].rsplit(':',1);refs[path].append((int(pos),row['declaration'].rsplit('.',1)[-1]))
with tarfile.open(arc,'r|gz') as tf:
 for entry in tf:
  if not entry.isfile():continue
  path=entry.name.removeprefix('./').removeprefix('lean/src/')
  if path not in refs:continue
  lines=tf.extractfile(entry).read().decode().split('\n')
  for pos,end in refs.pop(path):
   if not 0<pos<=len(lines):
    tally['out_of_range']+=1; continue
   tally['coordinate_exists']+=1
   if end in lines[pos-1]:tally['name_fragment_on_line']+=1
   elif len(issues)<10:issues.append({'path':path,'line':pos,'name_fragment':end})
   if end in ('b2PowA','secondCohomologyBound_of_boundaryBound') and len(anchors)<15:
    anchors.append({'path':path,'line':pos,'header_excerpt':' '.join(lines[pos-1:min(pos+2,len(lines))])[:440]})
(ev/'source-locations.json').write_text(json.dumps(dict(counts=tally,missing_files=len(refs),rows_in_missing_files=sum(len(r) for r in refs.values()),sample_unmatched_name_fragments=issues,selected_cohomology_headers=anchors,method='1-based LF line number and case-sensitive last name component substring. Coordinate check only.'),indent=2,ensure_ascii=False))
