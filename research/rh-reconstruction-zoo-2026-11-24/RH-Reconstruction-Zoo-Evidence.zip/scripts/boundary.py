"""Differential against the two published Markdown source tables. No graph indexes needed."""
from pathlib import Path
import csv, sys, re, json
root=Path(sys.argv[1]).resolve(); ev=Path(__file__).resolve().parents[1]/'evidence'
with (root/'audit/final_certification/Global_External_Boundary.tsv').open() as f:
 reader=csv.DictReader(f,delimiter='\t'); fields=reader.fieldnames; shipped=list(reader)
sources=['audit/pre_synthesis/Final_External_Fidelity/Authoritative_External_Theorem_Ledger.md','audit/Post_Closure_Verification_Boundary.md']
def reconstruct(safe):
 out=[]
 for idx,src in enumerate(sources):
  sec=None;block=''
  for line_no,line in enumerate((root/src).read_text().splitlines(),1):
   if idx==0 and line.startswith('## '):sec=next((t for s,t in [('1.','L'),('2.','R')] if line.startswith('## '+s)),None)
   if idx==1 and line.startswith('#'):block=line.strip('# ').strip()
   prefix= ('|---','| #','| id') if idx==0 else ('|---','| Theorem','| #','| ID')
   if not line.startswith('|') or line.startswith(prefix):continue
   stripped=line.strip().strip('|')
   parts=re.split(r'(?<!\\)\|',stripped) if safe else stripped.split('|')
   c=[s.strip() for s in parts]; row=None
   if idx==0 and sec=='L' and len(c)>=8:row=[c[0],c[2][:300],c[3][:200],c[1][:250],c[5],c[7][:200],'Authoritative_External_Theorem_Ledger.md §1']
   if idx==0 and sec=='R' and len(c)>=4:row=[c[0],c[1][:300],'','',c[2][:200],c[3][:250],'Authoritative_External_Theorem_Ledger.md §2']
   if idx==1 and len(c)>=3:row=['PCVB:'+block[:30],c[0][:300],'',c[1][:250],c[2][:200],'','Post_Closure_Verification_Boundary.md']
   if row:out.append((src,line_no,dict(zip(fields,[x.replace('\t',' ') for x in row]))))
 return out
old=reconstruct(False);new=reconstruct(True)
assert len(old)==len(new) and [r["id"] for _,_,r in old]==[r["id"] for r in shipped[:len(old)]]
drift=[]
changed=[]
for n,((src,line,r),(src2,line2,fixed)) in enumerate(zip(old,new),2):
 assert (src,line)==(src2,line2)
 if r!=shipped[n-2]:
  drift.append({'tsv_line':n,'source':src,'source_line':line,'id':r['id'],'differing_columns':[k for k in fields if r[k]!=shipped[n-2][k]]});continue
 if fixed!=r:
  changed.append({'tsv_line':n,'source':src,'source_line':line,'id':r['id'],'fields':{k:{'exported':r[k],'from_source':fixed[k]} for k in fields if r[k]!=fixed[k]}})
(ev/'boundary-diff.json').write_text(json.dumps(dict(all_rows=len(shipped),imported_rows=len(old),source_rows_reproduced=len(old)-len(drift),drift=drift,authored_supplement=len(shipped)-len(old),changed=changed),ensure_ascii=False,indent=2))
