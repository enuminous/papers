"""Bind target observations to four pinned Lean decision kernels; zoo checkout must be built."""
from pathlib import Path
import json, subprocess,sys
root=Path(sys.argv[1]).resolve();zoo=Path(sys.argv[2]).resolve()
ev=Path(__file__).resolve().parents[1]/'evidence'
diff=json.loads((ev/'boundary-diff.json').read_text()); scan=json.loads((ev/'archive-scan.json').read_text())
veto='not proved here even modulo' in (root/'manuscript/sec18_assembly.tex').read_text()
failed='FileNotFoundError' in (ev/'graph-replay.log').read_text()
assert veto and failed
assert 'RiemannHypothesis := rhOfAll' in (ev/'archive-Main.lean').read_text()
assert any('Formalism.VW.rh_of_every allChi' in line for line in scan['root_excerpt'])
assert any('UpperTheory.FinalTheorems.everyCharacter' in line for line in scan['root_excerpt'])
n=[len(r['fields']) for r in diff['changed']]
w=', '.join('⟨%d, %d.0, %d.0, 1.0⟩'%(i,i,i) for i in n)
s='''import Turtle
import Weasel
import Salmon
import Extensions
open Zoo

def scopeVeto : Turtle.Input := ⟨true, true, 0, 0, 0, 0.0, 3, 0.18, 0.05⟩
#guard Turtle.run scopeVeto == .notSupported
#guard Turtle.run {scopeVeto with anyApplicable := false} == .insufficient

def boundaryRows : List Weasel.Finding := [FINDINGS]
#guard (Weasel.retain 2 boundaryRows).length == RETAINED
#guard (Weasel.retain 0 boundaryRows).isEmpty

-- IDs: 0 riemannHypothesis; 1 rhOfAll; 2 rh_of_every; 3 allChi; 4 everyCharacter.
-- The bounded test stops before any uninspected parent list is consulted.
def parents : Nat → List Nat
  | 0 => [1]
  | 1 => [2,3]
  | 3 => [4]
  | _ => []
def boundedFrontier : Bool := match Salmon.trace parents 2 0 with
  | .branch 0 [.branch 1 [.exhausted 2, .exhausted 3]] => true
  | _ => false
#guard boundedFrontier

def graphGate : Extensions.Circus.Summary := ⟨true, false, false, false, true, true, true, true⟩
#guard Extensions.Circus.decideGate graphGate == .fail
#guard Extensions.Circus.decideGate {graphGate with riskOpen := false, checkFailed := false} == .na
#guard Extensions.Circus.decideGate ⟨false,false,false,false,false,false,false,true⟩ == .pass
'''.replace('FINDINGS',w).replace('RETAINED',str(sum(i<=2 for i in n)))
lean=ev/'TargetGates.lean'; lean.write_text(s)
proc=subprocess.run(['lake','env','lean','-DwarningAsError=true',str(lean)],cwd=zoo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(ev/'target-gates.log').write_bytes(b'$ lake env lean -DwarningAsError=true TargetGates.lean\n'+proc.stdout+f'EXIT {proc.returncode}\n'.encode());proc.check_returncode()
(ev/'target-gates.json').write_text(json.dumps(dict(TURTLE='notSupported',WEASEL={'budget':2,'changed_field_counts':n,'retained':sum(i<=2 for i in n)},SALMON='two exhausted boundary nodes at depth 2',CIRCUS='fail',guards=8,control_semantics='TURTLE empty is insufficient; WEASEL zero budget retains none; CIRCUS missing-only is na, complete clean is pass'),indent=2))
